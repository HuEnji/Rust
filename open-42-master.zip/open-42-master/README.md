# Rust 42

Rust 语言的云核编码大赛参赛项目框架。

本仓库包含以下内容：

- AI 训练框架
- AI 执行引擎
- 本地对战平台
- 自动打包系统

## 背景

### Rust

- Rust 已经连续七年成为全世界最受欢迎的语言，没有 GC 也无需手动内存管理，性能比肩 C++/C ，安全性极高。
- Rust 已经纳入公司推荐系统编程语言，公司部分核心软件会用 Rust 重写，新软件也可能大量使用 Rust 编写。
- 学习一门语言的最好途径就是实践。

## 安装

### 依赖

本项目需要 rust 开发环境，建议从公司链接[下载](https://openx.huawei.com/Rust/download)。

本项目运行时有以下依赖：

- gcc
- g++
- pkg-config
- fontconfig
- libfontconfig-dev

另外，如果使用 torch 作为后端，还需要在环境上安装[libtorch](https://pytorch.org/get-started/locally/)。

建议使用 vscode+rust-analyzer 插件搭建开发环境。

### 下载

通过以下命令将项目克隆到本地：

```bash
git clone https://lfg-y.codehub.huawei.com/h00579717/open-42.git
```

## 使用说明

可以通过以下命令执行对应的操作：

```bash
cargo run -r --bin arena                              # 根据arena.json中的配置进行本地堆栈
cargo run -r --bin pack                               # 根据官方格式打包
cargo run -r --bin train -m vdn                       # 使用vdn算法开始训练
cargo run -r --bin train -m vdn -p model/train/last   # 基于指定的端点使用vdn算法继续训练
```

代码提交时，可以通过以下命令对代码进行检查：

```bash
cargo fmt -- --check
cargo clippy --all-targets -- -D warnings
cargo test
```

为了减少安装部署难度，coregeek 模块默认使用纯 rust 实现的 ndarray 作为后端；可以通过修改 packages/coregeek/Cargo.toml 中的 features 字段进行配置。

## 维护者

[@Hua Zhechen](https://codehub-y.huawei.com/users/h00579717)

## 如何贡献

非常欢迎你的加入：

- [提一个 Issue](https://codehub-y.huawei.com/h00579717/open-42/issues/new)
- [提交一个 Merge Request](https://codehub-y.huawei.com/h00579717/open-42/merge_requests/new)

## 使用许可

[MIT](LICENSE) © Hua Zhechen
