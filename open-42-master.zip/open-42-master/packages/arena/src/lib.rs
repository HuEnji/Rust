mod agent;
mod model;

use std::io::{self, Write};

use agent::{Agent, AgentPara};
use coregeek::{
    game::{Side, State},
    util,
};
use serde::Deserialize;

#[derive(Deserialize)]
#[serde(rename_all = "lowercase")]
pub enum Pause {
    None,
    Match,
    Turn,
    Step,
}

pub fn pause(state: &State) {
    state.print();
    let mut input = String::new();
    io::stdin().read_line(&mut input).unwrap();
}

#[derive(Deserialize)]
pub struct ArenaPara {
    ally: AgentPara,
    enemy: AgentPara,
    pause: Pause,
}

impl ArenaPara {
    pub fn build(self) -> Arena {
        Arena {
            ally: self.ally.build(),
            enemy: self.enemy.build(),
            pause: self.pause,
        }
    }
}

pub struct Arena {
    pub ally: Agent,
    pub enemy: Agent,
    pause: Pause,
}

impl Arena {
    pub fn challenge(&mut self) -> (i32, i32) {
        let state = State::gen();
        let (mut ally_score, mut enemy_score) = (0, 0);
        for side in [Side::Black, Side::White] {
            let mut state = state.clone();
            loop {
                let agent = if side == state.side {
                    &mut self.ally
                } else {
                    &mut self.enemy
                };
                let steps = agent.steps(&state);

                for step in steps.into_iter() {
                    state.exec_step(step);
                    if matches!(self.pause, Pause::Step) {
                        util::clear_screen();
                        println!("{}:", agent.name());
                        pause(&state);
                    }
                }

                print!("#");
                io::stdout().flush().unwrap();

                if matches!(self.pause, Pause::Turn) {
                    util::clear_screen();
                    println!("{}:", agent.name());
                    pause(&state);
                }
                let done = state.next_turn();

                if done {
                    if matches!(self.pause, Pause::Match) {
                        util::clear_screen();
                        println!("{}:", agent.name());
                        pause(&state);
                    }
                    match side {
                        Side::Black => {
                            ally_score += state.black.real_score();
                            enemy_score += state.white.real_score();
                        }
                        Side::White => {
                            ally_score += state.white.real_score();
                            enemy_score += state.black.real_score();
                        }
                    }
                    println!();
                    break;
                }
            }
        }
        (ally_score, enemy_score)
    }
}
