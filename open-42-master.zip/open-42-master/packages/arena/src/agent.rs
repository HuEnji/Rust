use std::sync::Arc;

use coregeek::{
    api::{Dir, STEP_NUM},
    engine::Engine,
    game::{Action, State, Step, Steps},
    model::Dqn,
    policy::{GreedyModel, RandomModel, StayModel, WrapModel},
    Backend, Model,
};
use serde::Deserialize;

use crate::model::NextModel;

fn model(name: &str) -> Arc<dyn Model> {
    match name {
        "next" => Arc::<NextModel>::default(),
        "greedy" => Arc::<GreedyModel>::default(),
        "random" => Arc::<RandomModel>::default(),
        "stay" => Arc::<StayModel>::default(),
        path => Arc::new(Dqn::<Backend>::load(path)),
    }
}

#[derive(Deserialize)]
pub struct WrapPara {
    name: String,
    width: usize,
}

#[derive(Deserialize)]
pub struct EnginePara {
    name: String,
    timeout: u64,
    test: bool,
}

#[derive(Deserialize)]
#[serde(rename_all = "lowercase")]
pub enum AgentPara {
    Model(String),
    Wrap(WrapPara),
    Engine(EnginePara),
}

impl AgentPara {
    pub fn build(self) -> Agent {
        match self {
            AgentPara::Model(name) => Agent::Model(format!("model-{}", name), model(&name)),
            AgentPara::Wrap(para) => Agent::Model(
                format!("wrap-{}-{}", para.name, para.width),
                Arc::new(WrapModel {
                    model: model(&para.name),
                    width: para.width,
                }),
            ),
            AgentPara::Engine(para) => Agent::Engine(
                format!("engine-{}-{}-{}", para.name, para.timeout, para.test),
                Engine::new(model(&para.name), para.timeout, para.test),
            ),
        }
    }
}

pub enum Agent {
    Model(String, Arc<dyn Model>),
    Engine(String, Engine),
}

impl Agent {
    pub fn name(&self) -> String {
        match self {
            Agent::Engine(name, _) => name.clone(),
            Agent::Model(name, _) => name.clone(),
        }
    }

    pub fn steps(&mut self, state: &State) -> Steps {
        match self {
            Agent::Model(_, model) => {
                let mut state = state.clone();
                let mut steps = vec![];
                for _ in 0..STEP_NUM {
                    let entities = &state.ally().alives();
                    let actions = model.infer(&state).actions;
                    let step: Step = entities
                        .iter()
                        .zip(actions.iter())
                        .map(|(e, &action)| Action {
                            index: e.index,
                            dir: Dir::from(action),
                        })
                        .collect();
                    state.exec_step(step.clone());
                    steps.push(step);
                }
                steps
            }
            Agent::Engine(_, engine) => engine.think(state).steps,
        }
    }
}
