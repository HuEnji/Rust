use std::{env, time::Instant};

use arena::ArenaPara;
use coregeek::util;

#[derive(Debug, Default)]
struct Score {
    count: usize,
    win: usize,
    draw: usize,
    lose: usize,
    score: (i32, i32),
}

fn main() {
    env::set_var("RUST_BACKTRACE", "1");

    let path = util::find_relative("arena.json");
    let path = path.first().unwrap();
    let file = std::fs::File::open(path).unwrap();
    let reader = std::io::BufReader::new(file);
    let para: ArenaPara = serde_json::from_reader(reader).unwrap();
    let mut arena = para.build();

    let mut score = Score::default();
    let time = Instant::now();

    // matches
    loop {
        let result = arena.challenge();
        {
            score.count += 1;
            match result.0.cmp(&result.1) {
                std::cmp::Ordering::Less => {
                    score.lose += 1;
                }
                std::cmp::Ordering::Equal => {
                    score.draw += 1;
                }
                std::cmp::Ordering::Greater => {
                    score.win += 1;
                }
            }
            score.score.0 += result.0;
            score.score.1 += result.1;
        }
        let wins = score.win * 2 + score.draw;
        let wins = wins as f32 / score.count as f32 / 2.0;
        util::clear_screen();
        println!("{} vs {}", arena.ally.name(), arena.enemy.name());
        println!(
            "win rate: {:.3} of {} in {}s",
            wins,
            score.count,
            time.elapsed().as_secs()
        );
        println!("{:?}", score);
    }
}
