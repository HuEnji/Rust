use coregeek::{
    api::{Dir, STEP_NUM},
    game::State,
    InferResult, Model,
};

#[derive(Default)]
pub struct NextModel {}
impl Model for NextModel {
    fn infer(&self, state: &State) -> InferResult {
        let mut values = vec![];
        let mut actions = vec![];
        for e in state.ally().alives().iter() {
            let limit = (STEP_NUM - state.ally_steps.len()) as u8;
            let attacks_bfs = state.bfs_attackables(e.index);
            let mut value = Dir::sample();
            let prev = e.pos;
            for (a, v) in value.iter_mut().enumerate() {
                let dir = Dir::from(a);
                if !state.valid_action(e.index, dir) {
                    *v *= -128.0;
                    continue;
                }
                let next = prev + dir.delta();
                let dp = attacks_bfs[prev.x as usize][prev.y as usize];
                let dn = attacks_bfs[next.x as usize][next.y as usize];
                // 得分
                if dn == 1 {
                    *v *= 1024.0;
                    continue;
                }
                // 进攻
                if dn > 0 && dn < limit && dn < dp {
                    *v *= 128.0;
                    continue;
                }
                // 防守
                let dp = state.enemy_bfs[prev.x as usize][prev.y as usize];
                let dn = state.enemy_bfs[next.x as usize][next.y as usize];
                if dn > 0 || dp > 0 {
                    match dn.cmp(&dp) {
                        std::cmp::Ordering::Less => *v *= 16.0,
                        std::cmp::Ordering::Equal => (),
                        std::cmp::Ordering::Greater => *v /= 16.0,
                    }
                    continue;
                }
                // 聚集
                let mut dp = 0;
                let mut dn = 0;
                for mate in state.ally().alives().iter() {
                    if mate.index == e.index {
                        continue;
                    }
                    dp += mate.pos.chebyshev(&prev);
                    dn += mate.pos.chebyshev(&next);
                }
                match dn.cmp(&dp) {
                    std::cmp::Ordering::Less => *v *= 8.0,
                    std::cmp::Ordering::Equal => (),
                    std::cmp::Ordering::Greater => *v /= 8.0,
                }
            }
            let action = value
                .iter()
                .enumerate()
                .max_by(|a, b| a.1.partial_cmp(b.1).unwrap())
                .map(|(i, _)| i)
                .unwrap();
            values.push(value);
            actions.push(action);
        }
        InferResult { values, actions }
    }
}
