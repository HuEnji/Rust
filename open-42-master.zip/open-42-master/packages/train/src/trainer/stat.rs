use coregeek::game::Side;
use log::info;
use plotters::prelude::*;
use serde::{Deserialize, Serialize};
use std::{
    fs,
    path::Path,
    time::{Duration, Instant},
};

use crate::agent::MatchRecord;

use super::{TrainStage, TRAIN_STAGE_INTERVAL};

#[derive(Deserialize, Serialize, Default, Clone, Debug)]
pub struct LearnResult {
    pub src: f32,
    pub dst: f32,
    pub loss: f32,
}

impl LearnResult {
    pub fn mean(data: Vec<LearnResult>) -> Self {
        let len = data.len() as f32;
        let (mut src, mut dst, mut loss) = (0.0, 0.0, 0.0);
        for item in data {
            src += item.src;
            dst += item.dst;
            loss += item.loss;
        }
        let (src, dst, loss) = (src / len, dst / len, loss / len);
        Self { src, dst, loss }
    }
}

#[derive(Deserialize, Serialize, Debug)]
pub struct Stat {
    #[serde(skip, default = "Instant::now")]
    pub time: Instant, // 计时
    pub stage: TrainStage,         // 训练阶段
    pub duration: Duration,        // 耗时
    pub episode: usize,            // 训练轮次
    pub results: Vec<LearnResult>, // 训练结果
    pub score: Vec<(i32, i32)>,    // 得分
    pub round: Vec<i32>,           // 回合
}

const WIDTH: u32 = 640;
const HEIGHT: u32 = 480;

impl Stat {
    pub fn new(stage: TrainStage) -> Self {
        Self {
            time: Instant::now(),
            stage,
            duration: Default::default(),
            episode: Default::default(),
            results: Default::default(),
            score: Default::default(),
            round: Default::default(),
        }
    }

    pub fn record(&mut self, record: &MatchRecord, result: &LearnResult) {
        // 计数
        self.episode += 1;
        // 保存数据
        self.results.push(result.clone());
        let (ally_score, enemy_score) = match record.side {
            Side::Black => (
                record.finish.black.real_score(),
                record.finish.white.real_score(),
            ),
            Side::White => (
                record.finish.white.real_score(),
                record.finish.black.real_score(),
            ),
        };
        self.score.push((ally_score, enemy_score));
        self.round.push(record.finish.round);

        // 打印阶段
        let stage = match self.stage {
            TrainStage::Explore => format!(
                "\x1B[31m Explore: {} \x1B[0m",
                (self.episode - 1) / TRAIN_STAGE_INTERVAL + 1
            ),
            TrainStage::Exploit => format!(
                "\x1B[32m Exploit: {} \x1B[0m",
                (self.episode - 1) / TRAIN_STAGE_INTERVAL + 1
            ),
        };
        // 打印得分
        let score = match ally_score.cmp(&enemy_score) {
            std::cmp::Ordering::Less => {
                format!(
                    "\x1B[31m Lose:{:>5.0}:{:<5.0}\x1B[0m",
                    ally_score, enemy_score
                )
            }
            std::cmp::Ordering::Equal => format!(" Draw:{:>5.0}:{:<5.0}", ally_score, enemy_score),
            std::cmp::Ordering::Greater => {
                format!(
                    "\x1B[32m Win: {:>5.0}:{:<5.0}\x1B[0m",
                    ally_score, enemy_score
                )
            }
        };
        // 打印Q值
        let q = match result.src.partial_cmp(&result.dst) {
            Some(std::cmp::Ordering::Less) => {
                format!(
                    "\x1B[32m Q:{:>5.1} to {:<5.1}\x1B[0m",
                    result.src, result.dst
                )
            }
            Some(std::cmp::Ordering::Greater) => {
                format!(
                    "\x1B[31m Q:{:>5.1} to {:<5.1}\x1B[0m",
                    result.src, result.dst
                )
            }
            _ => format!(" Q:{:>5.1} to {:<5.1}", result.src, result.dst),
        };

        let duration = self.time.elapsed();
        self.time = Instant::now();
        self.duration += duration;
        info!(
            "│ Episode:{:4} │{}│ Match: {:3}/{:3} │ Time:{:>3}/{}s │{}│{}│ Loss: {:<6.1}│",
            self.episode,
            stage,
            (self.episode - 1) % TRAIN_STAGE_INTERVAL + 1,
            TRAIN_STAGE_INTERVAL,
            duration.as_secs(),
            self.duration.as_secs(),
            score,
            q,
            result.loss,
        );
    }

    pub fn wr(&self) -> f32 {
        self.score
            .iter()
            .rev()
            .take(TRAIN_STAGE_INTERVAL)
            .rev()
            .map(|&(ally, enemy)| match ally.cmp(&enemy) {
                std::cmp::Ordering::Less => 0.0,
                std::cmp::Ordering::Equal => 0.5,
                std::cmp::Ordering::Greater => 1.0,
            })
            .sum()
    }

    pub fn draw(&self, path: &str) {
        info!("Draw to {}", path);
        fs::create_dir_all(path).unwrap();
        self.draw_data(
            path,
            "value",
            &self.results.iter().map(|data| data.src).collect(),
        );
        self.draw_data(
            path,
            "error",
            &self
                .results
                .iter()
                .map(|data: &LearnResult| data.src - data.dst)
                .collect(),
        );
        self.draw_data(
            path,
            "loss",
            &self
                .results
                .iter()
                .map(|data: &LearnResult| data.loss)
                .collect(),
        );
        self.draw_data(
            path,
            "round",
            &self.round.iter().map(|&v| v as f32).collect(),
        );
        self.draw_data(
            path,
            "score",
            &self.score.iter().map(|&(score, _)| score as f32).collect(),
        );
        self.draw_data(
            path,
            "delta",
            &self
                .score
                .iter()
                .map(|&(ally, enemy)| (ally - enemy) as f32)
                .collect(),
        );
        self.draw_data(
            path,
            "win-lose",
            &self
                .score
                .iter()
                .map(|&(ally, enemy)| match ally.cmp(&enemy) {
                    std::cmp::Ordering::Less => -1.0,
                    std::cmp::Ordering::Equal => 0.0,
                    std::cmp::Ordering::Greater => 1.0,
                })
                .collect(),
        );
    }

    fn draw_data(&self, path: &str, name: &str, data: &Vec<f32>) {
        if data.is_empty() {
            return;
        }
        let name = format!("{:?}-{}", self.stage, name);
        let name = name.to_lowercase();

        let xy: Vec<(usize, f32)> = data.iter().enumerate().map(|(i, &v)| (i + 1, v)).collect();
        self.draw_xy(path, &name, &xy);

        let max = WIDTH as usize;
        if data.len() > max {
            let xy: Vec<(usize, f32)> = xy.into_iter().rev().take(max).rev().collect();
            self.draw_xy(path, &format!("{}-last", &name), &xy);
        }
    }

    fn draw_xy(&self, path: &str, name: &str, xy: &[(usize, f32)]) {
        let path = Path::new(path).join(format!("{}.png", name));
        let root = BitMapBackend::new(&path, (WIDTH, HEIGHT));
        let root = root.into_drawing_area();
        root.fill(&WHITE).unwrap();

        let y: Vec<f32> = xy.iter().map(|&(_, y)| y).collect();
        let mut sorted = y.clone();
        sorted.sort_by(|a, b| a.partial_cmp(b).unwrap());
        let (min, max) = (sorted.len() as f32 * 0.01, sorted.len() as f32 * 0.99);
        let (mut min, mut max) = (min as usize, max as usize);
        if min == max {
            min = min.saturating_sub(1);
            if max < sorted.len() {
                max += 1;
            }
        }
        let (min, max) = (sorted[min], sorted[max - 1]);
        let range = (max - min) * 0.1;
        let (mut min, mut max) = (min - range, max + range);
        if min == max {
            min = min.min(-1.0);
            max = max.max(1.0);
        }

        let mut chart = ChartBuilder::on(&root)
            .caption(name, ("sans-serif", 32.0))
            .margin(32)
            .set_label_area_size(LabelAreaPosition::Left, 64)
            .set_label_area_size(LabelAreaPosition::Bottom, 32)
            .build_cartesian_2d(xy[0].0..xy[xy.len() - 1].0, min..max)
            .unwrap();

        chart
            .configure_mesh()
            .label_style(("sans-serif", 16.0))
            .draw()
            .unwrap();

        chart
            .draw_series(
                xy.iter()
                    .map(|&(x, y)| Circle::new((x, y), 2, BLUE.filled())),
            )
            .unwrap();

        let len = y.len();
        let mut chunks = len / 10 / 2;
        if chunks < 10 {
            chunks = 10;
        }
        let mut avg: Vec<(usize, f32)> = xy.to_vec();
        for (mid, item) in avg.iter_mut().enumerate().take(len) {
            let start = if mid < chunks { 0 } else { mid - chunks };
            let end = if mid + chunks + 1 > len {
                len
            } else {
                mid + chunks + 1
            };
            let previous: f32 = y[start..end].iter().sum();
            item.1 = previous / (end - start) as f32;
        }
        chart
            .draw_series(LineSeries::new(avg, RED.stroke_width(2)))
            .unwrap();
    }
}
