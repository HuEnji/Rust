mod stat;
use log::*;
use serde::{Deserialize, Serialize};
pub use stat::*;

use std::{
    fs::{self, File},
    io::{BufReader, Write},
    path::Path,
};

use crate::{
    agent::{Agent, MatchRecord},
    common::EPSILON,
};

pub trait Learner {
    fn learn(&mut self, agent: &mut Agent, record: &MatchRecord) -> Option<LearnResult>;
    fn save(&self, path: &str);
    fn clear(&mut self);
}

#[derive(Deserialize, Serialize, Debug)]
#[serde(rename_all = "lowercase")]
pub enum TrainStage {
    Explore,
    Exploit,
}

impl TrainStage {
    pub fn next(&self) -> Self {
        match self {
            TrainStage::Explore => Self::Exploit,
            TrainStage::Exploit => Self::Explore,
        }
    }
}

pub struct Trainer<L>
where
    L: Learner,
{
    pub agent: Agent,      // 智能体
    pub learner: L,        // 学习模块
    pub stage: TrainStage, // 训练阶段
    pub explore: Stat,     // 探索统计
    pub exploit: Stat,     // 利用统计
}

const DRAW_INTERVAL: usize = 20;
const TRAIN_STAGE_INTERVAL: usize = 200;
const BETTER_THRESHOLD: f32 = 0.75;

impl<L> Trainer<L>
where
    L: Learner,
{
    pub fn new(path: Option<&str>, learner: L) -> Self {
        let mut stage = TrainStage::Explore;
        let mut explore = Stat::new(TrainStage::Explore);
        let mut exploit = Stat::new(TrainStage::Exploit);
        let agent = Agent::new(path);

        if let Some(path) = path {
            let file = fs::File::open(Path::new(path).join("explore.json")).unwrap();
            let reader = BufReader::new(file);
            explore = serde_json::from_reader(reader).unwrap();
            let file = fs::File::open(Path::new(path).join("exploit.json")).unwrap();
            let reader = BufReader::new(file);
            exploit = serde_json::from_reader(reader).unwrap();
            if explore.episode > exploit.episode {
                stage = TrainStage::Exploit;
            }
        }

        Self {
            agent,
            learner,
            stage,
            explore,
            exploit,
        }
    }

    fn save(&self, path: &str) {
        info!("Save to {}", path);
        fs::create_dir_all(path).unwrap();

        self.agent.save(path);
        self.learner.save(path);

        let json = serde_json::to_string(&self.explore).unwrap();
        let mut file = File::create(Path::new(&path).join("explore.json")).unwrap();
        file.write_all(json.as_bytes()).unwrap();

        let json = serde_json::to_string(&self.exploit).unwrap();
        let mut file = File::create(Path::new(&path).join("exploit.json")).unwrap();
        file.write_all(json.as_bytes()).unwrap();
    }

    pub fn train(&mut self) {
        loop {
            let epsilon = match self.stage {
                TrainStage::Explore => EPSILON,
                TrainStage::Exploit => 0.0,
            };
            let record = self.agent.run_match(epsilon);
            let result = self.learner.learn(&mut self.agent, &record);
            if result.is_none() {
                continue;
            }
            let result = result.unwrap();

            let stat = match self.stage {
                TrainStage::Explore => &mut self.explore,
                TrainStage::Exploit => &mut self.exploit,
            };

            // 统计
            stat.record(&record, &result);

            if stat.episode % DRAW_INTERVAL == 0 {
                let path = "model/train/last";
                stat.draw(path);
            }

            // 阶段结束
            if stat.episode % TRAIN_STAGE_INTERVAL == 0 {
                let id = stat.episode / TRAIN_STAGE_INTERVAL;
                let id = id % 10;
                // 利用结束看胜率
                if matches!(self.stage, TrainStage::Exploit) {
                    let wr = stat.wr();
                    info!("exploit win rate: {:.3}", wr);
                    if wr > BETTER_THRESHOLD {
                        info!("better!");
                        fs::create_dir_all("model/best/").unwrap();
                        self.agent.better(&format!("model/best/{}", stat.episode));
                    }
                }
                let path = format!("model/train/{}", id);
                self.save(&path);
                self.save("model/train/last");
                self.stage = self.stage.next();
            }

            // 更新target网络
            self.agent.target = self.agent.model.clone();
        }
    }
}
