use coregeek::Backend;

mod agent;
mod common;

pub mod dqn;
pub mod trainer;
pub mod vdn;

pub type ADBackend = burn_autodiff::ADBackendDecorator<Backend>;
