use burn::{
    nn::loss::{MSELoss, Reduction},
    optim::{GradientsParams, Optimizer},
    tensor::{Data, Tensor},
};
use coregeek::{game::Side, model::Dqn};

use crate::{
    agent::{Agent, MatchRecord, TurnRecord},
    common::{BATCH_SIZE, LEARN_RATE, MIN_MEMORY},
    trainer::LearnResult,
    ADBackend,
};

use super::{BatchTrainableData, Learner, ReplayData};

impl<O> Learner<O>
where
    O: Optimizer<Dqn<ADBackend>, ADBackend>,
{
    pub fn learn_match(&mut self, agent: &mut Agent, record: &MatchRecord) -> Option<LearnResult> {
        let mut results = vec![];
        let (ally, enemy) = match record.side {
            Side::Black => (&record.blacks, &record.whites),
            Side::White => (&record.whites, &record.blacks),
        };
        let turns = ally;
        for (i, turn) in turns.iter().take(turns.len() - 1).enumerate() {
            let next = &turns[i + 1];
            // 记录终步
            results.append(&mut self.learn_turn_last_step(agent, turn, next));

            // 记录单步
            results.append(&mut self.learn_turn_prev_step(agent, turn));
        }

        let turns = enemy;
        for turn in turns.iter().take(turns.len() - 1) {
            // 记录单步
            results.append(&mut self.learn_turn_prev_step(agent, turn));
        }
        if results.is_empty() {
            None
        } else {
            Some(LearnResult::mean(results))
        }
    }

    fn learn_turn_prev_step(&mut self, agent: &mut Agent, turn: &TurnRecord) -> Vec<LearnResult> {
        let mut results = vec![];
        let steps = &turn.steps;
        for (step_index, step) in steps.iter().take(steps.len() - 1).enumerate() {
            let next_state = &steps[step_index + 1].state;
            for item in step.actions.iter() {
                let data = ReplayData {
                    index: item.index,
                    prev: step.state.clone(),
                    action: item.action,
                    reward: item.reward,
                    next: next_state.clone(),
                    turn: false,
                    done: false,
                };
                self.memory.push(data);
            }
            let result = self.backward(agent);
            if let Some(result) = result {
                results.push(result);
            }
        }
        results
    }

    fn learn_turn_last_step(
        &mut self,
        agent: &mut Agent,
        turn: &TurnRecord,
        next: &TurnRecord,
    ) -> Vec<LearnResult> {
        let steps = &turn.steps;
        let next_state = &next.start;

        let step = steps.last().unwrap();
        for item in step.actions.iter() {
            let done = next.steps.is_empty() || next_state.ally().entities[item.index].dead();
            let data = ReplayData {
                index: item.index,
                prev: step.state.clone(),
                action: item.action,
                reward: item.reward,
                next: next_state.clone(),
                turn: true,
                done,
            };
            self.memory.push(data);
        }

        let result = self.backward(agent);
        if let Some(result) = result {
            vec![result]
        } else {
            vec![]
        }
    }

    fn backward(&mut self, agent: &mut Agent) -> Option<LearnResult> {
        if self.memory.len() < MIN_MEMORY {
            return None;
        }
        // 经验回放
        let replays = self.memory.sample(BATCH_SIZE);
        let data = BatchTrainableData::new(&replays);

        // 计算当前网络的下一步最优动作
        // [[v0...v8]; B]
        let eval_next_output = agent.model.forward(data.next.clone());
        // [[index]; B]
        let eval_next_actions = Tensor::argmax(eval_next_output.q, 1);

        // 计算目标网络的值
        // [[v0...v8]; B]
        let target_next_output = agent.target.forward(data.next.clone());
        // [[value]; B]
        let target_next_values = target_next_output.q.gather(1, eval_next_actions);

        // 预测值
        // [[v0...v8]; B]
        let eval_output = agent.model.forward(data.prev.clone());
        // [[value]; B]
        let eval_values = eval_output.q.gather(1, data.action);
        let src = eval_values.clone().mean().into_scalar();

        // 标签值
        // [[value]; B]
        let label_values = data.reward + data.gamma * target_next_values;
        let label_values = label_values.clamp(-1e3, 1e3);
        let dst = label_values.clone().mean().into_scalar();

        // 根据error更新优先级
        let errors = eval_values.clone() - label_values.clone();
        let errors: Data<f32, 2> = errors.to_data();
        let errors: Vec<(usize, f32)> = replays
            .iter()
            .zip(errors.value.iter())
            .map(|((index, _), error)| (*index, *error))
            .collect();
        for (index, error) in errors {
            self.memory.update(index, error);
        }

        // 获取loss
        let loss = MSELoss::new().forward(eval_values, label_values, Reduction::Auto);

        let grads = loss.backward();
        let grads = GradientsParams::from_grads(grads, &agent.model);
        agent.model = self.optimizer.step(LEARN_RATE, agent.model.clone(), grads);
        Some(LearnResult {
            src,
            dst,
            loss: loss.into_scalar(),
        })
    }
}
