use std::sync::Arc;

use burn::tensor::{backend::ADBackend, Float, Int, Tensor};
use coregeek::{
    api::{Dir, STEP_NUM},
    game::State,
    model::InputData,
};

#[derive(Clone, Debug)]
pub struct ReplayData {
    pub index: usize,     // 角色索引
    pub prev: Arc<State>, // 行动前状态
    pub action: usize,    // 动作
    pub reward: i32,      // 奖励
    pub next: Arc<State>, // 行动后状态
    pub turn: bool,       // 回合切换
    pub done: bool,       // 游戏结束
}

#[derive(Clone, Debug)]
pub struct BatchTrainableData<B: ADBackend> {
    pub prev: InputData<B>,          // 行动前状态
    pub action: Tensor<B, 2, Int>,   // 动作
    pub reward: Tensor<B, 2, Float>, // 奖励
    pub next: InputData<B>,          // 行动后状态
    pub gamma: Tensor<B, 2, Float>,  // 是否有下个状态
}

impl<B: ADBackend> BatchTrainableData<B>
where
    B::FloatElem: From<f32>,
    f32: From<B::FloatElem>,
{
    pub fn new(data: &Vec<(usize, &ReplayData)>) -> Self {
        let gamma = 0.1f32.powf(1.0 / (STEP_NUM * 4) as f32);
        let len = data.len();
        let mut prev_b = Vec::with_capacity(len);
        let mut prev_i = Vec::with_capacity(len);
        let mut actions = Vec::with_capacity(len);
        let mut rewards = Vec::with_capacity(len);
        let mut next_b = Vec::with_capacity(len);
        let mut next_i = Vec::with_capacity(len);
        let mut gammas = Vec::with_capacity(len);
        for (_, item) in data.iter() {
            let input = InputData::extract(&item.prev, item.index);
            prev_b.push(input.board);
            prev_i.push(input.info);
            let input = if item.done {
                InputData::default()
            } else {
                InputData::extract(&item.next, item.index)
            };
            next_b.push(input.board);
            next_i.push(input.info);
            actions.push(Tensor::from_ints([[item.action as i32]]));
            // 基础奖励为己方虚拟伤害
            let mut reward = item.reward as f32;
            if !item.prev.valid_action(item.index, Dir::from(item.action)) {
                reward -= 10.0;
            }
            // 回合结束补充己方受到的真实伤害
            if item.turn {
                let damaged = item.prev.ally().entities[item.index].damaged()
                    - item.next.ally().entities[item.index].damaged();
                reward += damaged as f32 * gamma.powi(STEP_NUM as i32);
            }
            rewards.push(Tensor::from_floats([[reward]]));
            if item.done {
                // done: 不递归
                gammas.push(Tensor::from_floats([[0.0]]));
            } else if item.turn {
                // turn: gamma^step
                gammas.push(Tensor::from_floats([[gamma.powi(STEP_NUM as i32)]]));
            } else {
                // gamma
                gammas.push(Tensor::from_floats([[gamma]]));
            }
        }
        Self {
            prev: InputData {
                board: Tensor::cat(prev_b, 0),
                info: Tensor::cat(prev_i, 0),
            },
            action: Tensor::cat(actions, 0),
            reward: Tensor::cat(rewards, 0),
            next: InputData {
                board: Tensor::cat(next_b, 0),
                info: Tensor::cat(next_i, 0),
            },
            gamma: Tensor::cat(gammas, 0),
        }
    }
}
