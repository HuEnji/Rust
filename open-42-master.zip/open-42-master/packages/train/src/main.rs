use std::env;

use burn::optim::AdamConfig;
use clap::Parser;
use coregeek::model::Dqn;
use train::{
    dqn::{self},
    trainer::Trainer,
    vdn, ADBackend,
};

#[derive(Parser, Debug)]
struct Args {
    #[arg(short, long)]
    path: Option<String>,
    #[arg(short, long)]
    model: String,
}

fn main() {
    env::set_var("RUST_BACKTRACE", "1");
    if cfg!(debug_assertions) {
        env::set_var("RUST_LOG", "debug");
    } else {
        env::set_var("RUST_LOG", "info");
    }
    env_logger::Builder::from_default_env()
        .format_timestamp(None)
        .format_level(false)
        .format_target(false)
        .format_module_path(false)
        .init();

    let args = Args::parse();
    let path = args.path.as_ref().map(AsRef::as_ref);

    match args.model.as_str() {
        "dqn" => {
            let optimizer = AdamConfig::new().init::<ADBackend, Dqn<ADBackend>>();
            let learner = dqn::Learner::new(path, optimizer);
            let mut trainer = Trainer::new(path, learner);
            trainer.train();
        }
        "vdn" => {
            let optimizer = AdamConfig::new().init::<ADBackend, Dqn<ADBackend>>();
            let learner = vdn::Learner::new(path, optimizer);
            let mut trainer = Trainer::new(path, learner);
            trainer.train();
        }
        _ => panic!("invalid model: {}", args.model),
    };
}
