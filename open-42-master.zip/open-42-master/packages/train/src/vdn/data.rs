use std::sync::Arc;

use burn::tensor::{backend::ADBackend, Data, Float, Int, Shape, Tensor};
use coregeek::{
    api::{ENTITY_NUM, STEP_NUM},
    game::State,
    model::InputData,
};

#[derive(Clone, Debug)]
pub struct ReplayData {
    pub prev: Arc<State>,    // 上一步开始
    pub next: Arc<State>,    // 下一步开始(可能是下回合)
    pub actions: Vec<usize>, // 每个人的动作
    pub turn: bool,          // 回合切换
    pub done: bool,          // 游戏结束
}

#[derive(Clone, Debug)]
pub struct BatchTrainableData<B: ADBackend> {
    pub prev: InputData<B>,          // 上一步
    pub action: Tensor<B, 3, Int>,   // 每个人的动作
    pub reward: Tensor<B, 3, Float>, // 奖励
    pub next: InputData<B>,          // 下一步
    pub gamma: Tensor<B, 3, Float>,  // 是否有下个状态
}

impl<B: ADBackend> BatchTrainableData<B>
where
    B::FloatElem: From<f32>,
    B::IntElem: From<i32>,
    f32: From<B::FloatElem>,
{
    pub fn new(data: &Vec<(usize, &ReplayData)>) -> Self {
        let gamma = 0.1f32.powf(1.0 / (STEP_NUM * 4) as f32);
        let len = data.len();
        let mut prev_b = Vec::with_capacity(len);
        let mut prev_i = Vec::with_capacity(len);
        let mut actions = Vec::with_capacity(len);
        let mut rewards = Vec::with_capacity(len);
        let mut next_b = Vec::with_capacity(len);
        let mut next_i = Vec::with_capacity(len);
        let mut gammas = Vec::with_capacity(len);
        for (_, item) in data.iter() {
            for (a, e) in item
                .prev
                .ally()
                .entities
                .iter()
                .zip(item.next.ally().entities.iter())
            {
                let input = if !a.dead() {
                    InputData::extract(&item.prev, a.index)
                } else {
                    InputData::default()
                };
                prev_b.push(input.board);
                prev_i.push(input.info);

                let input = if e.dead() {
                    InputData::default()
                } else {
                    InputData::extract(&item.next, e.index)
                };
                next_b.push(input.board);
                next_i.push(input.info);
            }
            // 基础奖励为己方虚拟伤害
            let mut reward = (item.next.ally().reward_fake - item.prev.ally().reward_fake) as f32;
            if item.done {
                // 游戏结束获得生命得分奖励
                reward += item.prev.ally().life_score() as f32
            } else if item.turn {
                // 回合结束奖励为敌方的真实伤害
                let hurt = item.prev.enemy().reward_real - item.next.enemy().reward_real;
                reward += hurt as f32 * gamma.powi(STEP_NUM as i32)
            };
            rewards.push(Tensor::from_floats([[[reward]]]));
            let action = Data::new(
                item.actions
                    .iter()
                    .map(|&v| B::IntElem::from(v as i32))
                    .collect(),
                Shape {
                    dims: [1, ENTITY_NUM, 1],
                },
            );
            let action: Tensor<B, 3, Int> = Tensor::from_data(action);
            actions.push(action);
            if item.done {
                // done: 不递归
                gammas.push(Tensor::from_floats([[[0.0]]]));
            } else if item.turn {
                // turn: gamma^step
                gammas.push(Tensor::from_floats([[[gamma.powi(STEP_NUM as i32)]]]));
            } else {
                // gamma
                gammas.push(Tensor::from_floats([[[gamma]]]));
            }
        }
        Self {
            prev: InputData {
                board: Tensor::cat(prev_b, 0),
                info: Tensor::cat(prev_i, 0),
            },
            action: Tensor::cat(actions, 0),
            reward: Tensor::cat(rewards, 0),
            next: InputData {
                board: Tensor::cat(next_b, 0),
                info: Tensor::cat(next_i, 0),
            },
            gamma: Tensor::cat(gammas, 0),
        }
    }
}
