use burn::{
    nn::loss::{MSELoss, Reduction},
    optim::{GradientsParams, Optimizer},
    tensor::{Data, Shape, Tensor},
};
use coregeek::{
    api::{Dir, ENTITY_NUM},
    game::Side,
    model::Dqn,
};

use crate::{
    agent::{Agent, MatchRecord, TurnRecord},
    common::{BATCH_SIZE, LEARN_RATE, MIN_MEMORY},
    trainer::LearnResult,
    ADBackend,
};

use super::{BatchTrainableData, Learner, ReplayData};

impl<O> Learner<O>
where
    O: Optimizer<Dqn<ADBackend>, ADBackend>,
{
    pub fn learn_match(&mut self, agent: &mut Agent, record: &MatchRecord) -> Option<LearnResult> {
        let mut results = vec![];
        let (ally, enemy) = match record.side {
            Side::Black => (&record.blacks, &record.whites),
            Side::White => (&record.whites, &record.blacks),
        };
        let turns = ally;
        for (i, turn) in turns.iter().take(turns.len() - 1).enumerate() {
            let next = &turns[i + 1];
            // 记录终步
            results.append(&mut self.learn_turn_last_step(agent, turn, next));

            // 记录单步
            results.append(&mut self.learn_turn_prev_step(agent, turn));
        }

        let turns = enemy;
        for turn in turns.iter().take(turns.len() - 1) {
            // 记录单步
            results.append(&mut self.learn_turn_prev_step(agent, turn));
        }
        if results.is_empty() {
            None
        } else {
            Some(LearnResult::mean(results))
        }
    }

    fn learn_turn_prev_step(&mut self, agent: &mut Agent, turn: &TurnRecord) -> Vec<LearnResult> {
        let mut results = vec![];
        let steps = &turn.steps;
        for (step_index, step) in steps.iter().take(steps.len() - 1).enumerate() {
            let next_state = &steps[step_index + 1].state;
            let mut actions: Vec<usize> = step.actions.iter().map(|a| a.action).collect();
            actions.resize(ENTITY_NUM, Dir::N.value());
            let data = ReplayData {
                prev: step.state.clone(),

                next: next_state.clone(),
                actions,
                turn: false,
                done: false,
            };
            self.memory.push(data);
            let result = self.backward(agent);
            if let Some(result) = result {
                results.push(result);
            }
        }
        results
    }

    fn learn_turn_last_step(
        &mut self,
        agent: &mut Agent,
        turn: &TurnRecord,
        next: &TurnRecord,
    ) -> Vec<LearnResult> {
        let steps = &turn.steps;
        let next_state = &next.start;

        let step = steps.last().unwrap();
        let done = next.steps.is_empty();
        let mut actions: Vec<usize> = step.actions.iter().map(|a| a.action).collect();
        actions.resize(ENTITY_NUM, Dir::N.value());
        let data = ReplayData {
            prev: step.state.clone(),
            next: next_state.clone(),
            actions,
            turn: true,
            done,
        };
        self.memory.push(data);
        let result = self.backward(agent);
        if let Some(result) = result {
            vec![result]
        } else {
            vec![]
        }
    }

    fn backward(&mut self, agent: &mut Agent) -> Option<LearnResult> {
        if self.memory.len() < MIN_MEMORY {
            return None;
        }
        // 经验回放
        let replays = self.memory.sample(BATCH_SIZE);
        let data = BatchTrainableData::new(&replays);

        let batch = data.gamma.shape().dims[0];

        // 计算当前网络的下一步最优动作
        // [[v0..v8]; B * ENTITY_NUM]
        let eval_next_output = agent.model.forward(data.next.clone());
        // [[index]; B * ENTITY_NUM]
        let eval_next_actions = Tensor::argmax(eval_next_output.q, 1);
        // [[[index]; ENTITY_NUM]; B]
        let eval_next_actions = eval_next_actions.reshape(Shape {
            dims: [batch, ENTITY_NUM, 1],
        });

        // 计算目标网络的值
        // [[[sum]]; B]
        let target_next_values = agent.target.sum(data.next.clone(), eval_next_actions);

        // 预测值
        // [[[sum]]; B]
        let eval_values = agent.model.sum(data.prev.clone(), data.action);
        let src = eval_values.clone().mean().into_scalar();

        // 标签值
        // [[[sum]]; B]
        let label_values = data.reward + data.gamma * target_next_values;
        let label_values = label_values.clamp(-1e4, 1e4);
        let dst = label_values.clone().mean().into_scalar();

        // 根据error更新优先级
        let errors = eval_values.clone() - label_values.clone();
        let errors: Data<f32, 3> = errors.to_data();
        let errors: Vec<(usize, f32)> = replays
            .iter()
            .zip(errors.value.iter())
            .map(|((index, _), error)| (*index, *error))
            .collect();
        for (index, error) in errors {
            self.memory.update(index, error);
        }

        // 获取loss
        let loss = MSELoss::new().forward(eval_values, label_values, Reduction::Auto);

        let grads = loss.backward();
        let grads = GradientsParams::from_grads(grads, &agent.model);
        agent.model = self.optimizer.step(LEARN_RATE, agent.model.clone(), grads);
        Some(LearnResult {
            src,
            dst,
            loss: loss.into_scalar(),
        })
    }
}
