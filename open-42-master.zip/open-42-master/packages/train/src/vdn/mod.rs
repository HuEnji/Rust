mod data;
use std::{fs, path::Path};

use burn::{
    optim::Optimizer,
    record::{DefaultRecorder, Recorder},
};
use coregeek::model::Dqn;
pub use data::*;
mod learn;
pub use learn::*;

use crate::{
    agent::{Agent, MatchRecord},
    common::{Memory, REPLAY_SIZE},
    trainer, ADBackend,
};

pub struct Learner<O>
where
    O: Optimizer<Dqn<ADBackend>, ADBackend>,
{
    pub memory: Memory<ReplayData>, // 回放
    pub optimizer: O,               // 优化器
}

impl<O> Learner<O>
where
    O: Optimizer<Dqn<ADBackend>, ADBackend>,
{
    pub fn new(path: Option<&str>, mut optimizer: O) -> Self {
        let memory = Memory::new(REPLAY_SIZE, 1.0, 10.0);
        if let Some(path) = path {
            let recorder = DefaultRecorder::new();
            let record = recorder
                .load::<O::Record>(Path::new(path).join("optimizer"))
                .unwrap();
            optimizer = optimizer.load_record(record);
        }
        Self { memory, optimizer }
    }
}

impl<O> trainer::Learner for Learner<O>
where
    O: Optimizer<Dqn<ADBackend>, ADBackend>,
{
    fn learn(&mut self, agent: &mut Agent, record: &MatchRecord) -> Option<trainer::LearnResult> {
        self.learn_match(agent, record)
    }

    fn save(&self, path: &str) {
        fs::create_dir_all(path).unwrap();

        let recorder = DefaultRecorder::new();
        let record = self.optimizer.to_record();
        recorder
            .record(record, Path::new(&path).join("optimizer"))
            .unwrap();
    }

    fn clear(&mut self) {
        self.memory.clear();
    }
}
