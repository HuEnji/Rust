mod run;
pub use run::*;

use coregeek::{
    game::Side,
    model::Dqn,
    policy::{GreedyModel, WrapModel},
};
use log::*;
use std::{
    any::type_name,
    fs::{self},
    path::Path,
    sync::Arc,
};

use crate::ADBackend;

pub struct Agent {
    pub side: Side,             // 当前执方
    pub model: Dqn<ADBackend>,  // 当前网络
    pub target: Dqn<ADBackend>, // 目标网络
    pub enemy: WrapModel,       // 敌方策略
}

impl Agent {
    pub fn new(path: Option<&str>) -> Self {
        info!("Backend: {}", type_name::<ADBackend>());
        let side = Side::White;
        let mut model = Dqn::default();
        let mut enemy = WrapModel {
            model: Arc::new(GreedyModel::default()),
            width: 3,
        };

        if let Some(path) = path {
            model = Dqn::load(Path::new(&path).join("model"));
            if Path::new(&path).join("best.mpk.gz").exists() {
                enemy = WrapModel {
                    model: Arc::new(Dqn::<ADBackend>::load(Path::new(&path).join("best"))),
                    width: 2,
                };
            }
        }
        let target = model.clone();
        Self {
            side,
            model,
            target,
            enemy,
        }
    }

    pub fn save(&self, path: &str) {
        fs::create_dir_all(path).unwrap();

        self.model.save(Path::new(&path).join("model"));
    }

    pub fn better(&mut self, path: &str) {
        self.model.save(Path::new(&path));
        self.enemy = WrapModel {
            model: Arc::new(self.model.clone()),
            width: 2,
        }
    }
}
