use std::sync::Arc;

use coregeek::{
    api::{Dir, STEP_NUM},
    game::{Action, Side, State, Step},
    Model,
};
use rand::Rng;

use super::Agent;

pub struct ActionRecord {
    pub index: usize,  // 角色索引
    pub action: usize, // 角色动作
    pub reward: i32,   // 角色奖励
}

pub struct StepRecord {
    pub state: Arc<State>,          // 初始状态
    pub actions: Vec<ActionRecord>, // 每个角色的动作
}

pub struct TurnRecord {
    pub start: Arc<State>,      // 开始状态
    pub steps: Vec<StepRecord>, // 每一步的状态和动作
    pub finish: Arc<State>,     // 结束状态
}

pub struct MatchRecord {
    pub side: Side,              // 己方执方
    pub blacks: Vec<TurnRecord>, // 黑方记录
    pub whites: Vec<TurnRecord>, // 白方记录
    pub finish: Arc<State>,      // 终局状态
}

impl Agent {
    fn run_step(&self, state: &mut State, epsilon: f32) -> StepRecord {
        // 生成动作
        let prev = Arc::new(state.clone());
        let step = self.policy(&prev, epsilon);

        // 执行动作获得奖励
        let rewards = state.exec_step(step.clone());
        let entities = prev.ally().alives();
        let actions = entities
            .iter()
            .zip(step.iter())
            .zip(rewards.iter())
            .map(|((e, action), &reward)| ActionRecord {
                index: e.index,
                action: action.dir.value(),
                reward,
            })
            .collect();
        // 返回用于缓存
        StepRecord {
            state: prev,
            actions,
        }
    }

    fn run_turn(&self, state: &mut State, epsilon: f32) -> (TurnRecord, bool) {
        let start = Arc::new(state.clone());
        let mut steps = vec![];
        for _ in 0..STEP_NUM {
            let step = self.run_step(state, epsilon);
            steps.push(step);
        }
        let finish = Arc::new(state.clone());
        let done = state.next_turn();
        (
            TurnRecord {
                start,
                steps,
                finish,
            },
            done,
        )
    }

    pub fn run_match(&mut self, epsilon: f32) -> MatchRecord {
        self.side = self.side.next();
        let mut state = State::gen();

        let mut done = false;
        let mut record;
        let mut blacks = vec![];
        let mut whites = vec![];
        while !done {
            // 每回合
            let side = state.side;
            (record, done) = self.run_turn(&mut state, epsilon);
            match side {
                Side::Black => blacks.push(record),
                Side::White => whites.push(record),
            }
        }
        // 为双方添加假结局
        let mut fake = state.clone();
        for _ in 0..2 {
            let side = fake.side;
            let arc = Arc::new(fake.clone());
            let turn = TurnRecord {
                start: arc.clone(),
                steps: vec![],
                finish: arc.clone(),
            };
            match side {
                Side::Black => blacks.push(turn),
                Side::White => whites.push(turn),
            }
            fake.next_turn();
        }
        MatchRecord {
            side: self.side,
            blacks,
            whites,
            finish: Arc::new(state),
        }
    }

    fn policy_ally(&self, state: &State, epsilon: f32) -> Step {
        let entities = &state.ally().alives();
        // 模型生成动作
        let mut actions = self.model.infer(state).actions;
        let mut rng = rand::thread_rng();
        for action in actions.iter_mut() {
            if rng.gen_bool(epsilon as f64) {
                // 探索
                *action = Dir::random().value();
            }
        }
        entities
            .iter()
            .zip(actions.iter())
            .map(|(e, &action)| Action {
                index: e.index,
                dir: Dir::from(action),
            })
            .collect()
    }

    fn policy_enemy(&self, state: &State) -> Step {
        let entities = &state.ally().alives();
        let actions = self.enemy.infer(state).actions;
        entities
            .iter()
            .zip(actions.iter())
            .map(|(e, &action)| Action {
                index: e.index,
                dir: Dir::from(action),
            })
            .collect()
    }

    fn policy(&self, state: &State, epsilon: f32) -> Step {
        let ally = state.side == self.side;
        if ally {
            self.policy_ally(state, epsilon)
        } else {
            self.policy_enemy(state)
        }
    }
}
