mod memory;
pub use memory::*;

pub const LEARN_RATE: f64 = 3e-4;
pub const BATCH_SIZE: usize = 64;
pub const REPLAY_SIZE: usize = 1 << 20;
pub const EPSILON: f32 = 0.382;
pub const MIN_MEMORY: usize = 100000;
