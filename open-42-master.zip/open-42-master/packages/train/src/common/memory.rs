use rand::Rng;

#[derive(Clone)]
struct SumTree {
    capacity: usize,
    index: usize,
    value: Vec<f64>,
}

impl SumTree {
    fn new(capacity: usize) -> Self {
        SumTree {
            capacity,
            index: 0,
            value: vec![0.0; 2 * capacity - 1],
        }
    }

    /// 插入一个权重并返回数据索引
    ///
    /// - 参数
    ///   - `weight`: 权重
    /// - 返回值
    ///   -  `usize`: 数据索引
    fn push(&mut self, weight: f64) -> usize {
        let index = self.index;
        self.update(index, weight);
        self.index = (index + 1) % self.capacity;
        index
    }

    /// 根据数据索引更新权重
    ///
    /// - 参数
    ///   - `index`: 数据索引
    ///   - `weight`: 权重
    fn update(&mut self, index: usize, weight: f64) {
        let mut index = index + self.capacity - 1;
        let delta = weight - self.value[index];
        self.value[index] = weight;
        while index != 0 {
            index = (index - 1) / 2;
            self.value[index] += delta;
        }
    }

    /// 根据比例获取数据索引
    ///
    /// - 参数
    ///   - `ratio`: [0, 1]范围内的比例
    /// - 返回值
    ///   -  `usize`: 数据索引
    fn get(&self, ratio: f64) -> usize {
        let mut value = ratio * self.value[0];
        let mut index = 0;
        loop {
            let left = 2 * index + 1;
            let right = left + 1;
            if left >= self.value.len() {
                break;
            }
            if value <= self.value[left] {
                index = left;
            } else {
                value -= self.value[left];
                index = right;
            }
        }
        index + 1 - self.capacity
    }
}

pub struct Memory<T> {
    tree: SumTree,
    data: Vec<T>,
    capacity: usize,
    alpha: f64,
    epsilon: f64,
}

impl<T> Memory<T> {
    pub fn new(capacity: usize, alpha: f64, epsilon: f64) -> Self {
        Self {
            tree: SumTree::new(capacity),
            data: Vec::with_capacity(capacity),
            capacity,
            alpha,
            epsilon,
        }
    }

    /// 插入一个数据
    ///
    /// - 参数
    ///   - `data`: 数据
    pub fn push(&mut self, data: T) {
        let total = self.tree.value[0];
        let len = self.len();
        let avg = if len == 0 {
            self.epsilon.powf(self.alpha)
        } else {
            total / len as f64
        };
        let index = self.tree.push(avg * 3.0);
        if index < self.data.len() {
            self.data[index] = data;
        } else {
            debug_assert!(index == self.data.len());
            self.data.push(data);
        }
    }

    /// 采样
    ///
    /// - 参数
    ///   - `amount`: 采样数量
    pub fn sample(&mut self, amount: usize) -> Vec<(usize, &T)> {
        let mut rng = rand::thread_rng();
        let mut data = Vec::with_capacity(amount);
        for _ in 0..amount {
            let ratio = rng.gen::<f64>();
            let index = self.tree.get(ratio).min(self.data.len() - 1);
            data.push((index, &self.data[index]));
            // 防止重复抽到
            self.tree.update(index, 0.0);
        }
        data
    }

    /// 根据数据索引和error值更新权重
    ///
    /// - 参数
    ///   - `index`: 数据索引
    ///   - `error`: error
    pub fn update(&mut self, index: usize, error: f32) {
        let weight = (error.abs() as f64 + self.epsilon).powf(self.alpha);
        self.tree.update(index, weight);
    }

    /// 清空记忆
    pub fn clear(&mut self) {
        self.tree = SumTree::new(self.capacity);
        self.data = Vec::with_capacity(self.capacity);
    }

    pub fn len(&self) -> usize {
        self.data.len()
    }
}
