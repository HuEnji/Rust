pub mod api;
pub mod combine;
pub mod engine;
pub mod game;
pub mod model;
pub mod policy;
pub mod util;

use std::sync::{Arc, Mutex};

use api::{Input, DIR_NUM};
use engine::{Engine, SearchResult};
use log::*;

use crate::game::State;

pub struct InferResult {
    pub values: Vec<[f32; DIR_NUM]>,
    pub actions: Vec<usize>,
}

pub trait Model: Send + Sync + 'static {
    fn infer(&self, state: &State) -> InferResult;
}

pub fn entry(engine: Arc<Mutex<Engine>>, input: Input) -> SearchResult {
    let json = serde_json::to_string(&input).unwrap();
    info!("input: {:#}", json);
    let state: State = input.into();
    let mut engine = engine.lock().unwrap();
    let result = engine.think(&state);
    let json = serde_json::to_string(&result).unwrap();
    info!("output: {:#}", json);
    result
}

#[cfg(feature = "ndarray")]
pub type Backend = burn_ndarray::NdArrayBackend<f32>;
#[cfg(feature = "tch")]
pub type Backend = burn_tch::TchBackend<f32>;
#[cfg(feature = "wgpu")]
pub type Backend = WgpuBackend<AutoGraphicsApi, f32, i32>;
