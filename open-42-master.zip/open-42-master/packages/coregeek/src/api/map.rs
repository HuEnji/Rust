use super::{Pos, MAP_SIZE};
use serde::{ser::SerializeStruct, Deserialize, Serialize};
use std::collections::HashMap;

#[derive(Deserialize, Serialize, Clone, Copy, Debug, Default)]
#[serde(rename_all = "lowercase")]
pub enum Terrain {
    #[default]
    Space,
    Mountain,
}

impl Terrain {
    pub fn from<T: Into<u8>>(value: T) -> Self {
        let value = value.into();
        match value {
            0 => Self::Space,
            1 => Self::Mountain,
            _ => panic!("invalid tile role: {}", value),
        }
    }

    pub fn value(&self) -> u8 {
        match self {
            Self::Space => 0,
            Self::Mountain => 1,
        }
    }
}

#[derive(Clone, Debug, Default)]
pub struct Map {
    pub tiles: [[u8; MAP_SIZE]; MAP_SIZE],
}

impl Serialize for Map {
    fn serialize<S>(&self, serializer: S) -> Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        let mut tiles = [[0; MAP_SIZE]; MAP_SIZE];
        for (x, row) in self.tiles.iter().enumerate() {
            for (y, role) in row.iter().enumerate() {
                tiles[x][y] = (*role) as usize;
            }
        }
        let mut vec = vec![];
        for row in tiles.iter() {
            let row: Vec<String> = row.iter().map(ToString::to_string).collect();
            vec.push(row.join(" "));
        }
        let mut map = serializer.serialize_struct("map", 1)?;
        map.serialize_field("tiles", &vec)?;
        map.end()
    }
}

impl<'de> Deserialize<'de> for Map {
    fn deserialize<D>(deserializer: D) -> Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        #[derive(Deserialize, Debug)]
        pub struct Zone {
            pub pos: Pos,
            #[serde(rename = "roleType")]
            pub terrain: Terrain,
        }

        #[derive(Deserialize)]
        #[serde(rename_all = "lowercase")]
        enum ZoneTileEnum {
            Zones(Vec<Zone>),
            Tiles(Vec<String>),
        }

        #[derive(Deserialize)]
        struct MapInfo {
            #[serde(rename = "height", default)]
            _height: usize,
            #[serde(rename = "width", default)]
            _width: usize,
            #[serde(flatten)]
            value: ZoneTileEnum,
        }

        let info: MapInfo = serde::Deserialize::deserialize(deserializer)?;
        let mut map = Map::default();
        match info.value {
            ZoneTileEnum::Zones(zones) => {
                let mut dict = HashMap::new();
                for zone in zones.iter() {
                    dict.insert(&zone.pos, zone);
                }
                for x in 0..MAP_SIZE {
                    for y in 0..MAP_SIZE {
                        let pos = Pos::new(x as i32, y as i32);
                        if let Some(t) = dict.get(&pos) {
                            map.tiles[x][y] = t.terrain.value();
                        }
                    }
                }
            }
            ZoneTileEnum::Tiles(lines) => {
                let mut tiles = vec![];
                for line in lines.iter() {
                    let row: Vec<u8> = line.split(' ').map(|x| x.parse::<u8>().unwrap()).collect();
                    tiles.push(row);
                }
                for (x, row) in tiles.iter().enumerate() {
                    for (y, &v) in row.iter().enumerate() {
                        map.tiles[x][y] = v;
                    }
                }
            }
        }
        Ok(map)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn tiles() {
        let src = r#"
            "mapInfo": {
                "tiles": [
                "0 0 1 1 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0",
                "0 0 0 0 0 0 0 1 0 0 0 0 1 1 0 0 0 0 0 1 0",
                "0 0 0 0 0 0 0 0 0 0 0 1 0 0 0 1 1 0 0 0 0",
                "0 0 0 0 0 0 0 0 0 0 0 1 0 0 1 1 1 1 0 0 0",
                "0 0 0 0 0 0 0 0 0 1 0 0 0 0 1 0 0 1 0 1 0",
                "1 0 0 1 1 0 0 0 0 1 0 0 1 0 0 0 0 0 0 1 0",
                "1 0 0 1 1 0 0 0 0 0 0 0 1 0 0 1 0 0 0 0 0",
                "0 0 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 1",
                "0 0 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 1 1 0 0",
                "1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 1 0 0 0",
                "0 0 0 0 1 1 0 0 0 0 0 0 0 1 1 0 0 0 0 0 0",
                "0 0 0 0 0 1 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0",
                "1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0",
                "0 0 0 0 1 1 0 0 1 0 1 0 1 1 1 0 0 0 0 0 0",
                "0 0 1 1 1 0 0 0 0 0 0 0 0 0 0 0 0 1 1 0 0",
                "0 0 1 1 1 0 0 0 0 0 0 0 0 0 0 0 0 1 1 0 0",
                "1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 1 0 0",
                "1 0 0 0 0 0 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0",
                "0 0 0 1 0 0 0 0 0 0 0 0 1 0 0 0 0 0 0 0 1",
                "0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0",
                "0 0 0 0 0 0 0 1 0 0 0 1 0 1 0 1 0 1 1 0 0"
                ]
            }
        "#;
        let map: Map = serde_json::from_str(src).unwrap();
        let dst = serde_json::to_string(&map).unwrap();
        dbg!(dst);
    }

    #[test]
    fn zones() {
        let src = r#"
        "mapInfo": {
            "height": 21,
            "width": 21,
            "zones": [
              {
                "pos": {
                  "x": 0,
                  "y": 0
                },
                "roleType": "space"
              },
              {
                "pos": {
                  "x": 1,
                  "y": 1
                },
                "roleType": "mountain"
              }
            ]
          }
        "#;
        let map: Map = serde_json::from_str(src).unwrap();
        let dst = serde_json::to_string(&map).unwrap();
        dbg!(dst);
    }
}
