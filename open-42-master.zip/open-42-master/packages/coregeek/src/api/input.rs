use super::{Map, Teams};
use serde::{Deserialize, Serialize};

#[derive(Deserialize, Serialize, Clone, Debug)]
pub struct Input {
    #[serde(rename = "roundNo")]
    pub round: i32,
    #[serde(rename = "mapInfo")]
    pub map: Map,
    #[serde(rename = "players")]
    pub teams: Teams,
}

impl Input {
    pub fn string(&self) -> String {
        serde_json::to_string(&self).unwrap()
    }
}
