use super::Pos;
use serde::{Deserialize, Serialize};

#[derive(Deserialize, Serialize, Clone, Debug)]
pub struct Plan {
    #[serde(rename = "roleId")]
    pub id: i32,
    #[serde(rename = "posList")]
    pub path: Vec<Pos>,
}

#[derive(Deserialize, Serialize, Default, Clone, Debug)]
pub struct Output {
    #[serde(rename = "soldiers")]
    pub soldiers: Vec<Plan>,
}
