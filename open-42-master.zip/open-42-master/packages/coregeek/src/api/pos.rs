use super::MAP_SIZE;
use rand::{distributions::WeightedIndex, prelude::Distribution, Rng};
use serde::{Deserialize, Serialize};
use std::{cmp, ops, vec};

#[derive(Debug, Clone, Copy, Deserialize, Serialize, Eq, Hash, PartialEq, Default)]
pub struct Pos {
    pub x: i32,
    pub y: i32,
}

impl Pos {
    pub fn new(x: i32, y: i32) -> Self {
        Pos { x, y }
    }
    pub fn set(&mut self, x: i32, y: i32) -> &Self {
        self.x = x;
        self.y = y;
        self
    }
    pub fn add(&mut self, rhs: &Self) -> &Self {
        self.x += rhs.x;
        self.y += rhs.y;
        self
    }
    pub fn sub(&mut self, rhs: &Self) -> &Self {
        self.x -= rhs.x;
        self.y -= rhs.y;
        self
    }
    pub fn chebyshev(&self, rhs: &Self) -> u32 {
        cmp::max(self.x.abs_diff(rhs.x), self.y.abs_diff(rhs.y))
    }
    pub fn valid(&self) -> bool {
        self.x >= 0 && self.x < MAP_SIZE as i32 && self.y >= 0 && self.y < MAP_SIZE as i32
    }

    pub fn neighbors(&self) -> Vec<Pos> {
        DRIVE_TABLE.data[self.x as usize][self.y as usize].clone()
    }
}

impl ops::Add for Pos {
    type Output = Pos;

    fn add(self, rhs: Pos) -> Pos {
        Pos {
            x: self.x + rhs.x,
            y: self.y + rhs.y,
        }
    }
}

impl ops::Sub for Pos {
    type Output = Pos;

    fn sub(self, rhs: Pos) -> Pos {
        Pos {
            x: self.x - rhs.x,
            y: self.y - rhs.y,
        }
    }
}

pub const DIR_NUM: usize = 9;
const DIR_SAMPLE_WEIGHT: [usize; DIR_NUM] = [16, 16, 8, 8, 1, 8, 8, 16, 16];

#[derive(Deserialize, Serialize, Default, Clone, Copy, Debug, PartialEq)]
pub enum Dir {
    UL,
    DL,
    L,
    U,
    #[default]
    N,
    D,
    R,
    UR,
    DR,
}

impl Dir {
    pub fn delta(&self) -> Pos {
        match self {
            Dir::UL => Pos::new(-1, -1),
            Dir::DL => Pos::new(-1, 1),
            Dir::L => Pos::new(-1, 0),
            Dir::U => Pos::new(0, -1),
            Dir::N => Pos::new(0, 0),
            Dir::D => Pos::new(0, 1),
            Dir::R => Pos::new(1, 0),
            Dir::UR => Pos::new(1, -1),
            Dir::DR => Pos::new(1, 1),
        }
    }

    pub fn from(value: usize) -> Self {
        match value {
            0 => Dir::UL,
            1 => Dir::DL,
            2 => Dir::L,
            3 => Dir::U,
            4 => Dir::N,
            5 => Dir::D,
            6 => Dir::R,
            7 => Dir::UR,
            8 => Dir::DR,
            _ => Dir::N,
        }
    }

    pub fn value(&self) -> usize {
        match self {
            Dir::UL => 0,
            Dir::DL => 1,
            Dir::L => 2,
            Dir::U => 3,
            Dir::N => 4,
            Dir::D => 5,
            Dir::R => 6,
            Dir::UR => 7,
            Dir::DR => 8,
        }
    }

    pub fn random() -> Dir {
        let dist = WeightedIndex::new(DIR_SAMPLE_WEIGHT).unwrap();
        let mut rng = rand::thread_rng();
        Dir::from(dist.sample(&mut rng))
    }

    pub fn sample() -> [f32; DIR_NUM] {
        let mut result = [0.0; DIR_NUM];
        let mut rng = rand::thread_rng();
        for (i, v) in result.iter_mut().enumerate() {
            *v = DIR_SAMPLE_WEIGHT[i] as f32 * rng.gen::<f32>();
        }
        result
    }
}

#[cfg(test)]
mod tests {
    use crate::api::DIR_NUM;

    use super::*;

    #[test]
    fn dir() {
        for i in 0..DIR_NUM {
            let dir = Dir::from(i);
            let v = dir.value();
            assert!(i == v);
        }
    }

    #[test]
    fn delta() {
        for i in 0..DIR_NUM {
            if i == Dir::N.value() {
                continue;
            }
            let a = Dir::from(i);
            let pos = Pos::default();
            let next = pos + a.delta();
            assert!(pos != next);
            let next = next - a.delta();
            assert!(pos == next);

            let b = Dir::from(DIR_NUM - i - 1);
            let next = pos + a.delta();
            let next = next + b.delta();
            assert!(pos == next);
        }
    }

    #[test]
    fn random() {
        let mut stat = vec![];
        for _ in 0..10000 {
            let mut pos = Pos::new((MAP_SIZE / 2) as i32, (MAP_SIZE / 2) as i32);
            let mut steps = 0;
            let mut visited = 0;
            let mut map = [[false; MAP_SIZE]; MAP_SIZE];
            while visited < MAP_SIZE * MAP_SIZE {
                let dir = Dir::random();
                if dir == Dir::N {
                    continue;
                }
                let next = pos + dir.delta();
                if !next.valid() {
                    continue;
                }
                steps += 1;
                pos = next;
                if !map[pos.x as usize][pos.y as usize] {
                    visited += 1;
                }
                map[pos.x as usize][pos.y as usize] = true;
            }
            stat.push(steps);
        }
        println!("{}", stat.iter().sum::<usize>());
    }
}

struct NeighborTable {
    data: [[Vec<Pos>; MAP_SIZE]; MAP_SIZE],
}

impl Default for NeighborTable {
    fn default() -> Self {
        let mut data: [[Vec<Pos>; MAP_SIZE]; MAP_SIZE] =
            vec![
                vec![Vec::<Pos>::with_capacity(DIR_NUM); MAP_SIZE]
                    .try_into()
                    .unwrap();
                MAP_SIZE
            ]
            .try_into()
            .unwrap();
        for (x, line) in data.iter_mut().enumerate() {
            for (y, v) in line.iter_mut().enumerate() {
                let pos = Pos::new(x as i32, y as i32);
                for i in 0..DIR_NUM {
                    let dir = Dir::from(i);
                    if matches!(dir, Dir::N) {
                        continue;
                    }
                    let next = pos + dir.delta();
                    if next.valid() {
                        v.push(next);
                    }
                }
            }
        }
        Self { data }
    }
}

use once_cell::sync::Lazy;
static DRIVE_TABLE: Lazy<NeighborTable> = Lazy::new(NeighborTable::default);
