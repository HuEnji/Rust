mod pos;
use std::ops::Range;

pub use pos::*;

mod map;
pub use map::*;

mod role;
pub use role::*;

mod team;
pub use team::*;

mod input;
pub use input::*;

mod output;
pub use output::*;

pub const ROUND_NUM: usize = 100;

pub const MAP_SIZE: usize = 21;
pub const ENTITY_NUM: usize = 10;
pub const STEP_NUM: usize = 10;

pub const LIFE_SCORE: i32 = 200;

pub const TILE_NUM: usize = MAP_SIZE * MAP_SIZE;
pub const MOUNTAIN_NUM: Range<usize> = 0..TILE_NUM / 4;

pub const TMOUT: u64 = 9000;
