use serde::{Deserialize, Serialize};

#[derive(Deserialize, Serialize, Clone, Copy, Debug, Default, PartialEq, Eq, Hash)]
#[serde(rename_all = "lowercase")]
pub enum Role {
    #[default]
    Special,
    Artillery,
    Infantry,
}

impl Role {
    pub fn from(value: usize) -> Self {
        match value {
            0 => Self::Special,
            1 => Self::Artillery,
            2 => Self::Infantry,
            _ => panic!("invalid entity role: {}", value),
        }
    }

    pub fn value(&self) -> usize {
        match self {
            Self::Special => 0,
            Self::Artillery => 1,
            Self::Infantry => 2,
        }
    }

    pub fn health(&self) -> i32 {
        100
    }
    pub fn life(&self) -> i32 {
        2
    }
    pub fn damage(&self) -> i32 {
        match self {
            Role::Special => 11,
            Role::Artillery => 12,
            Role::Infantry => 10,
        }
    }
}
