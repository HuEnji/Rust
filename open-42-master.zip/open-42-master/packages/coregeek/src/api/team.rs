use super::{Pos, Role};
use serde::{Deserialize, Serialize};

#[derive(Deserialize, Serialize, Clone, Debug)]
pub struct Teams {
    #[serde(rename = "teamOur")]
    pub ally: AllyTeam,
    #[serde(rename = "teamEnemy")]
    pub enemy: PosList,
}

#[derive(Deserialize, Serialize, Clone, Debug)]
pub struct AllyTeam {
    #[serde(rename = "totalScore")]
    pub score: i32,
    #[serde(rename = "teamId")]
    pub id: String,
    #[serde(rename = "teamName")]
    pub name: String,
    #[serde(rename = "roles")]
    pub entities: Vec<Ally>,
}
#[derive(Deserialize, Serialize, Clone, Debug)]
pub struct Ally {
    pub id: i32,
    pub pos: Pos,
    #[serde(rename = "roleType")]
    pub role: Role,
    pub health: i32,
    pub life: i32,
}

#[derive(Deserialize, Serialize, Clone, Debug)]
pub struct PosList {
    #[serde(rename = "posList")]
    pub entities: Vec<Enemy>,
}

pub type Enemy = Pos;
