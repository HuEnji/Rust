use coregeek::engine::Engine;
use coregeek::model::Dqn;
use coregeek::{api::*, entry, util, Backend};

use hyper::service::{make_service_fn, service_fn};
use hyper::{Body, Request, Response, Server};
use log::{error, info};
use std::any::type_name;
use std::sync::{Arc, Mutex};
use std::{convert::Infallible, env, net::SocketAddr};

async fn index(
    engine: Arc<Mutex<Engine>>,
    mut req: Request<Body>,
) -> Result<Response<Body>, Infallible> {
    let bytes = hyper::body::to_bytes(req.body_mut()).await.unwrap();
    let input = serde_json::from_slice::<Input>(bytes.to_vec().as_slice()).unwrap();
    let result = entry(engine, input);

    let json = serde_json::to_string(&result.output).unwrap();
    Ok(Response::new(Body::from(json)))
}

fn get_port() -> u16 {
    let args: Vec<String> = env::args().collect();
    if let Some(p) = args.get(1) {
        if let Ok(p) = p.parse::<u16>() {
            return p;
        }
    }
    6666
}

#[tokio::main]
async fn main() {
    env::set_var("RUST_BACKTRACE", "1");
    if cfg!(debug_assertions) {
        println!("debug version: {}", TIMESTAMP);
        env::set_var("RUST_LOG", "debug");
    } else {
        println!("release version: {}", TIMESTAMP);
        env::set_var("RUST_LOG", "info");
    }
    env_logger::init();

    info!("Backend: {}", type_name::<Backend>());
    let path = format!("model/best.mpk.gz");
    info!("Load model from {}", path);
    let path = util::find_relative(path);
    if path.is_empty() {
        panic!("Model not found");
    }
    let path = path.first().unwrap();
    let path = path.to_str().unwrap().to_string();
    let path = path.strip_suffix(".mpk.gz").unwrap();
    let model: Dqn<Backend> = Dqn::load(path);
    let model = Arc::new(model);

    let engine = Arc::new(Mutex::new(Engine::new(model, TMOUT, false)));

    let addr = SocketAddr::from(([127, 0, 0, 1], get_port()));
    let make_svc = make_service_fn(move |_conn| {
        let engine = engine.clone();
        async move {
            Ok::<_, Infallible>(service_fn(move |req: Request<Body>| {
                let engine = engine.clone();
                index(engine, req)
            }))
        }
    });
    let server = Server::bind(&addr).serve(make_svc);
    if let Err(e) = server.await {
        error!("server error: {}", e);
    }
}

const TIMESTAMP: &str = "YYYY-MM-DD hh:mm:ss";
