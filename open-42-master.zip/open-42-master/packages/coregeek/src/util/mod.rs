use std::{
    env,
    fmt::Debug,
    fs,
    io::{self, Write},
    path::{Path, PathBuf},
};

use crate::api::MAP_SIZE;

pub fn walk_dir<P: AsRef<Path>>(dir: P) -> Vec<PathBuf> {
    let mut entries = Vec::new();
    if let Ok(iter) = fs::read_dir(dir) {
        for entry in iter.flatten() {
            let path = entry.path();
            if path.is_dir() {
                entries.extend(walk_dir(&path));
            }
            entries.push(path);
        }
    }
    entries
}

pub fn find_relative<P: AsRef<Path>>(rel: P) -> Vec<PathBuf> {
    let mut vec = Vec::new();
    let dir = env::current_dir().unwrap();
    let entries = walk_dir(&dir);
    for path in entries {
        if path.ends_with(&rel) {
            vec.push(path);
        }
    }
    vec
}

pub fn clear_screen() {
    io::stdout().write_all(b"\x1B[2J\x1B[1;1H").unwrap();
    io::stdout().flush().unwrap();
}

pub fn print_map<T: Debug>(map: &[[T; MAP_SIZE]; MAP_SIZE]) {
    for y in 0..MAP_SIZE {
        for row in map.iter() {
            print!("{:?} ", row[y]);
        }
        println!();
    }
}

pub fn softmax(input: &[f32]) -> Vec<f32> {
    let mut values: Vec<f32> = Vec::new();
    let sum: f32 = input.iter().map(|&x| x.exp()).sum();
    for &value in input {
        let exp = value.exp();
        values.push(exp / sum);
    }
    values
}
