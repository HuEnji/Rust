use super::SearchResult;
use crate::{
    api::{Dir, DIR_NUM, STEP_NUM},
    combine::{ActionScore, IndexCombine, IndexCombineScore, StepPriority},
    game::{Action, State},
    policy::WrapModel,
    util::softmax,
    Model,
};
use std::{
    collections::{BinaryHeap, HashMap, HashSet},
    ops::Deref,
    sync::Arc,
    time::Instant,
};

#[derive(Clone, Default)]
pub struct StepNodePara {
    pub width: usize, // 可选动作
    pub test: bool,   // 测试标记
}

pub struct LeafNode {
    result: SearchResult,
}

fn simulate(model: &Arc<dyn Model>, state: &mut State) {
    let model = WrapModel {
        model: model.clone(),
        width: 2,
    };
    for _ in 0..STEP_NUM {
        let entities = &state.ally().alives();
        let actions = model.infer(state).actions;
        let step = entities
            .iter()
            .zip(actions.iter())
            .map(|(e, &action)| Action {
                index: e.index,
                dir: Dir::from(action),
            })
            .collect();
        state.exec_step(step);
    }
}

impl LeafNode {
    fn new(model: Arc<dyn Model>, state: Arc<State>, _para: StepNodePara) -> Self {
        let side = state.side;
        let output = state.ally().output();
        let steps = state.ally_steps.clone();

        let mut state = state.deref().clone();
        // 敌方不会死亡
        for e in state.enemy_mut().alives_mut().iter_mut() {
            e.health = i32::MAX;
        }
        // 切换到敌方回合
        let mut done = state.next_turn();
        // 初始得分
        let mut score = state.delta(side) as f32;
        if !done {
            simulate(&model, &mut state);
            done = state.next_turn();
            // 对手走完得分
            score = state.delta(side) as f32;
            // 预测将来得分
            if !done {
                let infer = model.infer(&state).values;
                let infer: f32 = infer
                    .iter()
                    .map(|values| values.iter().sum::<f32>() / DIR_NUM as f32)
                    .sum();
                let gamma = 0.1f32.powf(1.0 / (STEP_NUM * 4) as f32);
                score += infer * gamma * gamma;
            }
        }

        let result = SearchResult {
            output,
            steps,
            score,
            count: 1,
        };
        Self { result }
    }
}

pub struct BranchNode {
    model: Arc<dyn Model>,                     // 模型
    state: Arc<State>,                         // 状态
    table: Vec<StepPriority>,                  // 每个角色的方向评分表
    force: BinaryHeap<IndexCombineScore>,      // 即将被force的动作列表
    combines: BinaryHeap<IndexCombineScore>,   // 当前已经排序的动作列表
    children: HashMap<IndexCombine, StepNode>, // 根据动作列表生成的子节点
    para: StepNodePara,                        // 参数
}

impl BranchNode {
    fn new(model: Arc<dyn Model>, state: Arc<State>, para: StepNodePara) -> Self {
        let result = model.infer(&state);
        let entities = state.ally().alives();
        let mut table = vec![];
        for (e, actions) in entities.iter().zip(result.values) {
            let mut scores = vec![];
            let stay = ActionScore {
                dir: Dir::N,
                score: actions[Dir::N.value()],
            };
            let softmax = softmax(&actions);
            for (d, v) in actions.into_iter().enumerate() {
                if !state.valid_action(e.index, Dir::from(d)) {
                    continue;
                }
                if softmax[d] < 1.0 / DIR_NUM as f32 {
                    continue;
                }
                scores.push(ActionScore {
                    dir: Dir::from(d),
                    score: v,
                });
            }
            scores.sort_by(|a, b| b.score.partial_cmp(&a.score).unwrap());
            let mut scores: Vec<ActionScore> = scores.into_iter().take(para.width).collect();
            if !scores.iter().any(|s| s.dir == Dir::N) {
                if scores.len() < para.width {
                    scores.push(stay);
                } else {
                    scores[para.width - 1] = stay;
                }
            }
            table.push(StepPriority {
                index: e.index,
                actions: scores,
            });
        }

        let force = Default::default();
        let combines = Default::default();
        let children = Default::default();

        let mut node = Self {
            model,
            state,
            table,
            force,
            combines,
            children,
            para,
        };
        node.push(IndexCombine {
            indexes: vec![0; node.table.len()],
        });
        node
    }

    fn push(&mut self, combine: IndexCombine) {
        // 计算得分
        let score = combine.score(&self.table);
        let step = combine.step(&self.table);

        let score = IndexCombineScore { combine, score };

        if self.state.valid_step(&step) {
            self.combines.push(score.clone());
        }

        // 放到待force队列中
        self.force.push(score);
    }

    fn force(&mut self) {
        let last = self.force.pop().unwrap();
        let force = last.combine.force(&self.table);
        for next in force {
            self.push(next);
        }
    }

    fn search(
        &mut self,
        width: usize,
        deadline: Instant,
        best: &mut SearchResult,
        same: &mut HashSet<Arc<State>>,
    ) {
        while !self.force.is_empty() && self.combines.len() < width * 1024 {
            self.force();
        }
        for combine in self.combines.iter().take(width) {
            let child = self.children.get_mut(&combine.combine);
            if let Some(child) = child {
                child.search(width, deadline, best, same);
            } else {
                // 模拟执行
                let step = combine.combine.step(&self.table);
                let mut state = self.state.deref().clone();
                state.exec_step(step);
                let state = Arc::new(state);
                if same.contains(&state) {
                    continue;
                }
                // 子节点
                let mut child = StepNode::new(self.model.clone(), state, self.para.clone());
                child.search(width, deadline, best, same);
                self.children.insert(combine.combine.clone(), child);
            }
            if Instant::now() > deadline {
                return;
            }
        }
    }
}

pub enum StepNode {
    Leaf(LeafNode),
    Branch(BranchNode),
}

impl StepNode {
    pub fn new(model: Arc<dyn Model>, state: Arc<State>, para: StepNodePara) -> Self {
        // 根据当前状态判断节点类型
        let leaf = state.ally_steps.len() == STEP_NUM;
        if leaf {
            Self::Leaf(LeafNode::new(model, state, para))
        } else {
            Self::Branch(BranchNode::new(model, state, para))
        }
    }

    pub fn search(
        &mut self,
        width: usize,
        deadline: Instant,
        best: &mut SearchResult,
        same: &mut HashSet<Arc<State>>,
    ) {
        match self {
            StepNode::Leaf(node) => best.compare(&node.result),
            StepNode::Branch(node) => node.search(width, deadline, best, same),
        }
    }
}
