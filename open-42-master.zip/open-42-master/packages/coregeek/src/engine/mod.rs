mod step;

use log::*;
use serde::{Deserialize, Serialize};
use std::collections::HashSet;
use std::time::Duration;
use std::{sync::Arc, time::Instant};

use crate::api::{Output, DIR_NUM};
use crate::engine::step::{StepNode, StepNodePara};
use crate::{game::*, Model};

#[derive(Deserialize, Serialize, Default, Clone, Debug)]
pub struct SearchResult {
    pub output: Output,
    pub steps: Steps,
    pub score: f32,
    pub count: usize,
}

impl SearchResult {
    pub fn compare(&mut self, next: &SearchResult) {
        self.count += 1;
        if next.score > self.score {
            self.score = next.score;
            self.output = next.output.clone();
            self.steps = next.steps.clone();
        }
    }
}

pub struct Engine {
    model: Arc<dyn Model>,
    timeout: u64,
    test: bool,
}

impl Engine {
    pub fn new(model: Arc<dyn Model>, timeout: u64, test: bool) -> Self {
        Self {
            model,
            timeout,
            test,
        }
    }

    pub fn think(&mut self, state: &State) -> SearchResult {
        info!("think");
        let now = Instant::now();
        let deadline = now + Duration::from_millis(self.timeout);

        let output = state.ally().output();
        let steps = state.ally_steps.clone();
        let mut best = SearchResult {
            score: f32::MIN,
            output,
            steps,
            count: 0,
        };
        let mut node = StepNode::new(
            self.model.clone(),
            Arc::new(state.clone()),
            StepNodePara {
                width: 5,
                test: self.test,
            },
        );
        let num = state.ally().alives().len();
        let max = DIR_NUM.pow(num as u32);
        for width in 1..=max {
            info!("width: {}", width);
            let mut same = HashSet::new();
            node.search(width, deadline, &mut best, &mut same);
            info!("count: {}", best.count);
            if Instant::now() > deadline {
                break;
            }
        }
        best
    }
}
