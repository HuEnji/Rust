use crate::{
    api::Dir,
    game::{Action, Step},
};

// 方向-评分
#[derive(Default, Debug, Clone)]
pub struct ActionScore {
    pub dir: Dir,
    pub score: f32,
}

// 每个角色根据评分排序
#[derive(Debug)]
pub struct StepPriority {
    pub index: usize,
    pub actions: Vec<ActionScore>,
}

// 用下标表示所有角色的方向组合
#[derive(Debug, PartialEq, Eq, Hash, Clone)]
pub struct IndexCombine {
    pub(super) indexes: Vec<usize>,
}

impl IndexCombine {
    // 获取此组合的动作
    pub(super) fn step(&self, table: &[StepPriority]) -> Step {
        self.indexes
            .iter()
            .enumerate()
            .map(|(ei, &ai)| Action {
                index: table[ei].index,
                dir: table[ei].actions[ai].dir,
            })
            .collect()
    }

    // 获取此组合的评分
    pub(super) fn score(&self, table: &[StepPriority]) -> f32 {
        self.indexes
            .iter()
            .enumerate()
            .map(|(ei, &ai)| table[ei].actions[ai].score)
            .sum()
    }

    // 将此组合劣化
    pub(super) fn force(&self, table: &[StepPriority]) -> Vec<Self> {
        let mut result = vec![];
        for (i, v) in self.indexes.iter().enumerate() {
            let value = v + 1;
            if value >= table[i].actions.len() {
                continue;
            }
            let mut item = Self {
                indexes: self.indexes.clone(),
            };
            item.indexes[i] = value;
            result.push(item);
        }
        result
    }
}

#[derive(Clone)]
pub struct IndexCombineScore {
    pub(super) combine: IndexCombine,
    pub(super) score: f32,
}

impl PartialEq for IndexCombineScore {
    fn eq(&self, other: &Self) -> bool {
        self.score == other.score
    }
}

impl Eq for IndexCombineScore {}

impl PartialOrd for IndexCombineScore {
    fn partial_cmp(&self, other: &Self) -> Option<std::cmp::Ordering> {
        Some(self.cmp(other))
    }
}

impl Ord for IndexCombineScore {
    fn cmp(&self, other: &Self) -> std::cmp::Ordering {
        self.score.partial_cmp(&other.score).unwrap()
    }
}
