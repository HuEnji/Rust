use super::State;
use crate::{
    api::{Pos, Role, Terrain, ENTITY_NUM, MAP_SIZE, MOUNTAIN_NUM},
    game::{Entity, Side, Team},
};
use rand::Rng;

pub fn gen_pos(block: &mut [[bool; MAP_SIZE]; MAP_SIZE]) -> Pos {
    let mut rng = rand::thread_rng();
    loop {
        let x = rng.gen_range(0..MAP_SIZE);
        let y = rng.gen_range(0..MAP_SIZE);
        if !block[x][y] {
            block[x][y] = true;
            return Pos::new(x as i32, y as i32);
        }
    }
}

impl Team {
    pub fn gen(used: &mut [[bool; MAP_SIZE]; MAP_SIZE]) -> Self {
        let mut entities = vec![];
        for i in 0..ENTITY_NUM {
            let role = Role::Artillery;
            entities.push(Entity::new(i as i32, i, gen_pos(used), role));
        }
        Self::new(0, entities)
    }
}

impl State {
    pub fn gen() -> Self {
        let mut rng = rand::thread_rng();
        let round = 1;
        let side = Side::Black;
        let mut used = [[false; MAP_SIZE]; MAP_SIZE];

        let mut map = [[0; MAP_SIZE]; MAP_SIZE];

        let mountains = rng.gen_range(MOUNTAIN_NUM);
        let mountain = Terrain::Mountain.value();
        for _ in 0..mountains {
            let pos = gen_pos(&mut used);
            map[pos.x as usize][pos.y as usize] = mountain;
        }

        let black = Team::gen(&mut used);
        let white = Team::gen(&mut used);
        Self::new(round, side, map, black, white)
    }
}
