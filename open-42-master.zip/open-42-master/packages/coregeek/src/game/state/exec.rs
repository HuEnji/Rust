use std::cmp::min;

use super::{gen_pos, State};
use crate::{
    api::{Dir, MAP_SIZE, ROUND_NUM},
    game::{Side, Step},
};

impl State {
    pub fn valid_action(&self, index: usize, dir: Dir) -> bool {
        let ally = self.ally();
        let entity = &ally.entities[index];
        debug_assert!(!entity.dead());
        // 检查新位置的合法性
        let next = entity.pos + dir.delta();
        // 出界
        if !next.valid() {
            return false;
        }
        let (x, y) = (next.x as usize, next.y as usize);
        // 地图
        if self.map[x][y] != 0 || self.enemy_bfs[x][y] == u8::MAX {
            return false;
        }
        true
    }

    pub fn valid_step(&self, step: &Step) -> bool {
        debug_assert!(step.len() == self.ally().alives().len());
        let ally = self.ally();

        let mut conflict = [[false; MAP_SIZE]; MAP_SIZE];
        // 检查新位置的合法性
        for action in step.iter() {
            let entity = &ally.entities[action.index];
            debug_assert!(!entity.dead());
            let next = entity.pos + action.dir.delta();
            // 出界
            if !next.valid() {
                return false;
            }
            let (x, y) = (next.x as usize, next.y as usize);
            // 冲突
            if conflict[x][y] {
                return false;
            }
            // 地图
            if self.map[x][y] != 0 || self.enemy_bfs[x][y] == u8::MAX {
                return false;
            }
            conflict[x][y] = true;
        }
        true
    }

    fn exec_step_conflict(&mut self, step: &mut Step) {
        debug_assert!(step.len() == self.ally().alives().len());

        let mut conflict = [[0; MAP_SIZE]; MAP_SIZE];
        // 检查单一非法位置
        for action in step.iter_mut() {
            let ally = self.ally_mut();
            let entity = &mut ally.entities[action.index];
            debug_assert!(!entity.dead());

            let prev = entity.pos;
            let next = prev + action.dir.delta();
            // 出界
            if !next.valid() {
                action.dir = Dir::N;
                conflict[prev.x as usize][prev.y as usize] += 1;
                continue;
            }
            let (x, y) = (next.x as usize, next.y as usize);
            // 非法
            if self.map[x][y] != 0 || self.enemy_bfs[x][y] == u8::MAX {
                action.dir = Dir::N;
                conflict[prev.x as usize][prev.y as usize] += 1;
                continue;
            }
            conflict[x][y] += 1;
        }
        // 检查内部冲突
        loop {
            let mut found = false;
            for action in step.iter_mut() {
                if matches!(action.dir, Dir::N) {
                    continue;
                }
                let ally = self.ally_mut();
                let entity = &mut ally.entities[action.index];
                debug_assert!(!entity.dead());

                let prev = entity.pos;
                let next = prev + action.dir.delta();
                let (x, y) = (next.x as usize, next.y as usize);
                // 发现冲突
                if conflict[x][y] > 1 {
                    action.dir = Dir::N;
                    found = true;
                    conflict[prev.x as usize][prev.y as usize] += 1;
                }
            }
            if !found {
                break;
            }
        }
    }

    /// 执行一步动作并返回得分
    pub fn exec_step(&mut self, mut step: Step) -> Vec<i32> {
        self.exec_step_conflict(&mut step);
        let mut rewards = vec![];
        let (ally, enemy) = self.teams_mut();
        for action in step.iter() {
            let entity = &mut ally.entities[action.index];
            debug_assert!(!entity.dead());

            let next = entity.pos + action.dir.delta();
            let mut reward_real = 0;
            let mut reward_fake = 0;
            // 攻击
            for (ti, target) in enemy.alives_mut().iter_mut().enumerate() {
                // 攻击过了
                if entity.attacked[ti] {
                    continue;
                }
                // 死亡
                if target.health <= 0 {
                    continue;
                }
                // 距离
                if next.chebyshev(&target.pos) != 1 {
                    continue;
                }
                entity.attacked[ti] = true;
                let damage = min(entity.role.damage(), target.health);
                reward_real += damage;
                reward_fake += entity.role.damage();
                target.health -= damage;
            }
            ally.reward_real += reward_real;
            ally.reward_fake += reward_fake;
            entity.reward_real += reward_real;
            entity.reward_fake += reward_fake;
            entity.pos = next;
            entity.path.push(next);
            // 执方并不知道敌方血量因此给与虚拟奖励
            rewards.push(reward_fake);
        }
        self.ally_steps.push(step);
        rewards
    }

    fn blocks(&self) -> [[bool; MAP_SIZE]; MAP_SIZE] {
        let mut blocks = [[false; MAP_SIZE]; MAP_SIZE];
        for (x, line) in self.map.iter().enumerate() {
            for (y, v) in line.iter().enumerate() {
                if *v != 0 {
                    blocks[x][y] = true;
                }
            }
        }
        for e in self.ally().alives().iter() {
            blocks[e.pos.x as usize][e.pos.y as usize] = true;
        }
        for e in self.enemy().alives().iter() {
            blocks[e.pos.x as usize][e.pos.y as usize] = true;
        }
        blocks
    }

    /// 结算死亡和复活
    pub fn settle(&mut self) {
        let mut blocks = self.blocks();
        for entity in self.enemy_mut().alives_mut().iter_mut() {
            if entity.health <= 0 && entity.life >= 0 {
                entity.life -= 1;
                if entity.life >= 0 {
                    entity.health = entity.role.health();
                    entity.pos = gen_pos(&mut blocks);
                }
            }
        }
    }

    /// 清理执方缓存
    pub fn clear(&mut self) {
        self.ally_mut().clear();
        // 清空steps
        self.ally_steps.clear();
    }

    /// 更新到下回合并返回是否结束
    pub fn next_turn(&mut self) -> bool {
        self.settle();
        self.clear();

        // 切换回合
        self.side = self.side.next();
        // 更新敌方地图
        self.bfs_enemy();

        if matches!(self.side, Side::Black) {
            self.round += 1;
        }
        // 回合数满
        if self.round > ROUND_NUM as i32 {
            self.round = ROUND_NUM as i32;
            return true;
        }
        // 己方阵亡
        let ally = self.ally_mut();
        if ally.alives().is_empty() {
            return true;
        }
        false
    }
}
