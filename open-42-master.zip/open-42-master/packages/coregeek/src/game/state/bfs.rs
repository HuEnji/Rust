use std::collections::VecDeque;

use crate::api::{Pos, MAP_SIZE, STEP_NUM, TILE_NUM};

use super::State;

impl State {
    /// 所有己方能到达的点
    pub fn bfs_ally(&self, index: usize) -> [[u8; MAP_SIZE]; MAP_SIZE] {
        let ally = self.ally();
        let limit = STEP_NUM - self.ally_steps.len();
        let a = &ally.entities[index];
        debug_assert!(!a.dead());
        let start = a.pos;

        let mut queue: VecDeque<Pos> = VecDeque::with_capacity(TILE_NUM);
        queue.push_back(start);

        let mut result = [[0; MAP_SIZE]; MAP_SIZE];

        while let Some(pos) = queue.pop_front() {
            let x = pos.x as usize;
            let y = pos.y as usize;
            let d = result[x][y] + 1;

            if d as usize > limit {
                continue;
            }

            for pos in pos.neighbors() {
                let x = pos.x as usize;
                let y = pos.y as usize;
                if self.map[x][y] != 0 || self.enemy_bfs[x][y] == u8::MAX || result[x][y] != 0 {
                    continue;
                }
                queue.push_back(pos);
                result[x][y] = d;
            }
        }
        if limit > 0 {
            result[start.x as usize][start.y as usize] = 1;
        }
        result
    }

    /// 每个点下回合可能被攻击的次数
    pub fn bfs_enemy(&mut self) {
        let enemy = self.enemy();
        let limit = STEP_NUM + 1;
        let mut result = [[0; MAP_SIZE]; MAP_SIZE];

        for e in enemy.alives().iter() {
            let mut queue: VecDeque<Pos> = VecDeque::with_capacity(TILE_NUM);
            let mut distance = [[0; MAP_SIZE]; MAP_SIZE];
            queue.push_back(e.pos);
            while let Some(pos) = queue.pop_front() {
                let x = pos.x as usize;
                let y = pos.y as usize;
                let d = distance[x][y] + 1;

                if d as usize > limit {
                    continue;
                }
                result[x][y] += 1;

                for pos in pos.neighbors() {
                    let x = pos.x as usize;
                    let y = pos.y as usize;
                    if self.map[x][y] != 0 || distance[x][y] != 0 {
                        continue;
                    }
                    queue.push_back(pos);
                    distance[x][y] = d;
                }
            }
        }
        for e in enemy.alives().iter() {
            let x = e.pos.x as usize;
            let y = e.pos.y as usize;
            result[x][y] = u8::MAX;
        }
        self.enemy_bfs = result
    }
    // 可攻击的敌人的多源BFS
    pub fn bfs_attackables(&self, index: usize) -> [[u8; MAP_SIZE]; MAP_SIZE] {
        let ally = self.ally();
        let a = &ally.entities[index];
        debug_assert!(!a.dead());
        let enemy = self.enemy();
        let limit = STEP_NUM - self.ally_steps.len();
        let mut queue: VecDeque<Pos> = VecDeque::with_capacity(TILE_NUM);
        for (ei, e) in enemy.alives().iter().enumerate() {
            if a.attacked[ei] {
                continue;
            }
            queue.push_back(e.pos);
        }

        let mut result = [[0; MAP_SIZE]; MAP_SIZE];

        while let Some(pos) = queue.pop_front() {
            let x = pos.x as usize;
            let y = pos.y as usize;
            let d = result[x][y] + 1;

            if d as usize > limit {
                continue;
            }

            for pos in pos.neighbors() {
                let x = pos.x as usize;
                let y = pos.y as usize;
                if self.map[x][y] != 0 || self.enemy_bfs[x][y] == u8::MAX || result[x][y] != 0 {
                    continue;
                }
                queue.push_back(pos);
                result[x][y] = d;
            }
        }
        for e in enemy.alives().iter() {
            result[e.pos.x as usize][e.pos.y as usize] = 1;
        }
        result
    }
}
