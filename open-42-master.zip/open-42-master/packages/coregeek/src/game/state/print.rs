use crate::{
    api::{Terrain, ENTITY_NUM, MAP_SIZE},
    game::Side,
};

use super::State;

const MOUNTAIN_TOKEN: char = '█';
const MAP_BORDER_TOKEN: [[char; 4]; 4] = [
    ['┌', '─', '┬', '┐'],
    ['│', ' ', '│', '│'],
    ['├', '─', '┼', '┤'],
    ['└', '─', '┴', '┘'],
];

pub const ENTITY_NAME_TOKEN: [char; 2] = ['a', 'A'];
pub const ENTITY_NAME_COLOR: [&str; 2] = ["\x1B[31m", "\x1B[32m"];
pub const COLOR_END: &str = "\x1B[0m";

impl State {
    fn gen_table_border(t: usize, w: usize, n: usize) -> Vec<String> {
        let mut result = vec![];
        result.push(MAP_BORDER_TOKEN[t][0].to_string());
        for _ in 1..n {
            result.push(MAP_BORDER_TOKEN[t][1].to_string().repeat(w));
            result.push(MAP_BORDER_TOKEN[t][2].to_string());
        }
        result.push(MAP_BORDER_TOKEN[t][1].to_string().repeat(w));
        result.push(MAP_BORDER_TOKEN[t][3].to_string());
        result
    }

    fn set_map_terrain(&self, data: &mut [Vec<String>]) {
        let mountain: u8 = Terrain::Mountain.value();

        for (x, row) in self.map.iter().enumerate() {
            for (y, &v) in row.iter().enumerate() {
                if v == mountain {
                    data[y * 2 + 1][x * 2 + 1] = MOUNTAIN_TOKEN.to_string().repeat(3);
                }
            }
        }

        for (x, row) in self.map.iter().enumerate() {
            for (y, &v) in row.iter().enumerate() {
                if v == mountain && x + 1 < self.map.len() && self.map[x + 1][y] == mountain {
                    data[y * 2 + 1][x * 2 + 2] = MOUNTAIN_TOKEN.to_string();
                }
                if v == mountain && y + 1 < row.len() && row[y + 1] == mountain {
                    data[y * 2 + 2][x * 2 + 1] = MOUNTAIN_TOKEN.to_string().repeat(3);
                }
            }
        }
    }

    fn set_map_enemy(&self, data: &mut [Vec<String>]) {
        let side = self.side.next().value();
        let token = ENTITY_NAME_TOKEN[side];
        let color = ENTITY_NAME_COLOR[side];
        for (ei, e) in self.enemy().alives().iter().enumerate() {
            data[(e.pos.y * 2 + 1) as usize][(e.pos.x * 2 + 1) as usize] = format!(
                "{} {} {}",
                color,
                (token as u8 + ei as u8) as char,
                COLOR_END
            )
        }
    }

    fn set_map_ally(&self, data: &mut [Vec<String>]) {
        let side = self.side.value();
        let token = ENTITY_NAME_TOKEN[side];
        let color = ENTITY_NAME_COLOR[side];
        for (ei, e) in self.ally().alives().iter().enumerate() {
            for (i, pos) in e.path.iter().enumerate() {
                data[(pos.y * 2 + 1) as usize][(pos.x * 2 + 1) as usize] = format!(
                    "{}{}-{}{}",
                    color,
                    (token as u8 + ei as u8) as char,
                    i,
                    COLOR_END
                );
            }
        }
        for (ei, e) in self.ally().alives().iter().enumerate() {
            data[(e.pos.y * 2 + 1) as usize][(e.pos.x * 2 + 1) as usize] = format!(
                "{}({}){}",
                color,
                (token as u8 + ei as u8) as char,
                COLOR_END
            );
        }
    }

    fn gen_info(&self) -> Vec<Vec<String>> {
        let mut info = vec![];

        // ROUND
        info.push(Self::gen_table_border(0, 9, 2));
        info.push(Self::gen_table_border(1, 9, 2));
        info.last_mut().unwrap()[1] = format!("{:^9}", "ROUND");
        info.last_mut().unwrap()[3] = format!("{:^9}", self.round);

        // TURN
        info.push(Self::gen_table_border(2, 9, 2));
        info.push(Self::gen_table_border(1, 9, 2));
        info.last_mut().unwrap()[1] = format!("{:^9}", "TURN");
        let side = format!("{:?}", self.side);
        info.last_mut().unwrap()[3] = format!("{:^9}", side);

        // STEP
        info.push(Self::gen_table_border(2, 9, 2));
        info.push(Self::gen_table_border(1, 9, 2));
        info.last_mut().unwrap()[1] = format!("{:^9}", "STEP");
        info.last_mut().unwrap()[3] = format!("{:^9}", self.ally_steps.len());
        info.push(Self::gen_table_border(3, 9, 2));

        info.push(vec!["".to_string()]);

        // SIDE
        info.push(Self::gen_table_border(0, 9, 2));
        info.push(Self::gen_table_border(1, 9, 2));
        let mut side = format!("{:?}", Side::Black);
        if matches!(self.side, Side::Black) {
            side = format!("*{}*", side);
        }
        info.last_mut().unwrap()[1] = format!("{:^9}", side);

        let mut side = format!("{:?}", Side::White);
        if matches!(self.side, Side::White) {
            side = format!("*{}*", side);
        }
        info.last_mut().unwrap()[3] = format!("{:^9}", side);

        // SCORE
        info.push(Self::gen_table_border(2, 9, 2));
        info.push(Self::gen_table_border(1, 9, 2));
        info.last_mut().unwrap()[1] = format!("{:^9}", self.black.real_score());
        info.last_mut().unwrap()[3] = format!("{:^9}", self.white.real_score());

        // HEALTH/LIFE
        for i in 0..ENTITY_NUM {
            info.push(Self::gen_table_border(2, 9, 2));
            info.push(Self::gen_table_border(1, 9, 2));
            if let Some(b) = self.black.entities.get(i) {
                info.last_mut().unwrap()[1] = format!(
                    " {}:{:>3}/{:<2}",
                    (ENTITY_NAME_TOKEN[0] as u8 + i as u8) as char,
                    b.health,
                    b.life
                );
            }
            if let Some(w) = self.white.entities.get(i) {
                info.last_mut().unwrap()[3] = format!(
                    " {}:{:>3}/{:<2}",
                    (ENTITY_NAME_TOKEN[1] as u8 + i as u8) as char,
                    w.health,
                    w.life
                );
            }
        }
        info.push(Self::gen_table_border(3, 9, 2));

        info
    }

    pub fn print(&self) {
        // 逐行生成地图
        let mut map = vec![];
        map.push(Self::gen_table_border(0, 3, MAP_SIZE));
        for _ in 1..MAP_SIZE {
            map.push(Self::gen_table_border(1, 3, MAP_SIZE));
            map.push(Self::gen_table_border(2, 3, MAP_SIZE));
        }
        map.push(Self::gen_table_border(1, 3, MAP_SIZE));
        map.push(Self::gen_table_border(3, 3, MAP_SIZE));

        // 设置地形信息
        self.set_map_terrain(&mut map);
        self.set_map_enemy(&mut map);
        self.set_map_ally(&mut map);

        let info = self.gen_info();
        for (i, line) in info.into_iter().enumerate() {
            map[i].extend(line);
        }

        for line in map.iter() {
            for seg in line.iter() {
                print!("{}", seg);
            }
            println!();
        }
    }
}
