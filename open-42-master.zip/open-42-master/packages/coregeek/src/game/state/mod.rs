use super::*;
use crate::api::*;

mod bfs;
pub use bfs::*;
mod exec;
pub use exec::*;
mod gen;
pub use gen::*;
mod print;
pub use print::*;

use std::hash::{Hash, Hasher};

#[derive(Clone, Debug)]
pub struct State {
    pub round: i32,                            // 回合数
    pub side: Side,                            // 当前执方
    pub map: [[u8; MAP_SIZE]; MAP_SIZE],       // 地形
    pub black: Team,                           // 黑方
    pub white: Team,                           // 白方
    pub ally_steps: Steps,                     // 己方行动记录
    pub enemy_bfs: [[u8; MAP_SIZE]; MAP_SIZE], // 敌方BFS
}

impl Hash for State {
    fn hash<H: Hasher>(&self, state: &mut H) {
        self.round.hash(state);
        self.side.hash(state);
        self.black.hash(state);
        self.white.hash(state);
        self.ally_steps.len().hash(state);
    }
}

impl PartialEq for State {
    fn eq(&self, other: &Self) -> bool {
        self.round == other.round
            && self.side == other.side
            && self.black == other.black
            && self.white == other.white
            && self.ally_steps.len() == other.ally_steps.len()
    }
}

impl Eq for State {}

impl State {
    fn new(
        round: i32,
        side: Side,
        map: [[u8; MAP_SIZE]; MAP_SIZE],
        black: Team,
        white: Team,
    ) -> Self {
        let mut result = Self {
            round,
            side,
            map,
            black,
            white,
            enemy_bfs: [[0; MAP_SIZE]; MAP_SIZE],
            ally_steps: Default::default(),
        };
        result.bfs_enemy();
        result
    }

    pub fn ally(&self) -> &Team {
        match self.side {
            Side::Black => &self.black,
            Side::White => &self.white,
        }
    }

    pub fn ally_mut(&mut self) -> &mut Team {
        match self.side {
            Side::Black => &mut self.black,
            Side::White => &mut self.white,
        }
    }

    pub fn enemy(&self) -> &Team {
        match self.side {
            Side::Black => &self.white,
            Side::White => &self.black,
        }
    }

    pub fn enemy_mut(&mut self) -> &mut Team {
        match self.side {
            Side::Black => &mut self.white,
            Side::White => &mut self.black,
        }
    }

    pub fn teams(&self) -> (&Team, &Team) {
        match self.side {
            Side::Black => (&self.black, &self.white),
            Side::White => (&self.white, &self.black),
        }
    }

    pub fn teams_mut(&mut self) -> (&mut Team, &mut Team) {
        match self.side {
            Side::Black => (&mut self.black, &mut self.white),
            Side::White => (&mut self.white, &mut self.black),
        }
    }

    /// 根据输入的执方获得分差
    pub fn delta(&self, side: Side) -> i32 {
        match side {
            Side::Black => self.black.real_score() - self.white.real_score(),
            Side::White => self.white.real_score() - self.black.real_score(),
        }
    }
}

impl From<Input> for State {
    fn from(input: Input) -> Self {
        let round = input.round;
        let side = Side::Black;
        let map = input.map.tiles;
        let black: Team = input.teams.ally.into();
        let mut score = 0;
        for e in black.alives().iter() {
            score += e.damaged();
        }
        let white: Team = (input.teams.enemy, score).into();
        Self::new(round, side, map, black, white)
    }
}

impl From<State> for Input {
    fn from(state: State) -> Input {
        let round = state.round;
        let map = Map { tiles: state.map };
        let side = state.side;
        let (ally, enemy) = match side {
            Side::Black => (state.black, state.white),
            Side::White => (state.white, state.black),
        };
        let teams = Teams {
            ally: ally.into(),
            enemy: enemy.into(),
        };
        Input { round, map, teams }
    }
}
