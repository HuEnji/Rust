use std::hash::{Hash, Hasher};

use crate::api::{Ally, Enemy, Pos, Role, ENTITY_NUM};

#[derive(Clone, Debug)]
pub struct Entity {
    pub id: i32,                      // id
    pub index: usize,                 // 索引
    pub pos: Pos,                     // 位置
    pub path: Vec<Pos>,               // 位置
    pub role: Role,                   // 角色
    pub health: i32,                  // 健康
    pub life: i32,                    // 生命
    pub attacked: [bool; ENTITY_NUM], // 攻击记录
    pub reward_real: i32,             // 不含过量伤害的真实得分
    pub reward_fake: i32,             // 包含过量伤害的虚假得分
}

impl Hash for Entity {
    fn hash<H: Hasher>(&self, state: &mut H) {
        self.id.hash(state);
        self.index.hash(state);
        self.pos.hash(state);
        self.role.hash(state);
        self.health.hash(state);
        self.life.hash(state);
        self.attacked.hash(state);
        self.reward_real.hash(state);
        self.reward_fake.hash(state);
    }
}

impl PartialEq for Entity {
    fn eq(&self, other: &Self) -> bool {
        self.id == other.id
            && self.index == other.index
            && self.pos == other.pos
            && self.role == other.role
            && self.health == other.health
            && self.life == other.life
            && self.attacked == other.attacked
            && self.reward_real == other.reward_real
            && self.reward_fake == other.reward_fake
    }
}

impl Entity {
    pub fn new(id: i32, index: usize, pos: Pos, role: Role) -> Self {
        Self {
            id,
            index,
            pos,
            path: vec![pos],
            role,
            health: role.health(),
            life: role.life(),
            attacked: [false; ENTITY_NUM],
            reward_real: 0,
            reward_fake: 0,
        }
    }

    pub fn damaged(&self) -> i32 {
        if self.life >= 0 {
            (self.role.life() - self.life + 1) * self.role.health() - self.health
        } else {
            (self.role.life() + 1) * self.role.health()
        }
    }

    /// 清理运行数据
    pub fn clear(&mut self) {
        self.path = vec![self.pos];
        self.attacked = [false; ENTITY_NUM];
    }

    pub fn dead(&self) -> bool {
        self.life < 0
    }
}

impl From<(usize, Ally)> for Entity {
    fn from((index, value): (usize, Ally)) -> Self {
        Self {
            id: value.id,
            index,
            pos: value.pos,
            path: vec![value.pos],
            role: value.role,
            health: value.health,
            life: value.life,
            attacked: [false; ENTITY_NUM],
            reward_real: 0,
            reward_fake: 0,
        }
    }
}

impl From<Entity> for Ally {
    fn from(entity: Entity) -> Ally {
        Ally {
            id: entity.id,
            pos: entity.pos,
            role: entity.role,
            health: entity.health,
            life: entity.life,
        }
    }
}

impl From<(usize, Enemy)> for Entity {
    fn from((index, pos): (usize, Enemy)) -> Self {
        let role = Default::default();
        Self::new(index as i32, index, pos, role)
    }
}

impl From<Entity> for Enemy {
    fn from(entity: Entity) -> Enemy {
        entity.pos
    }
}
