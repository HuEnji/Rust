use serde::{Deserialize, Serialize};

use crate::api::Dir;

#[derive(Deserialize, Serialize, Clone, Debug)]
pub struct Action {
    pub index: usize,
    pub dir: Dir,
}
pub type Step = Vec<Action>;
pub type Steps = Vec<Step>;
