#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash)]
pub enum Side {
    Black,
    White,
}

impl Side {
    pub fn from(value: usize) -> Self {
        match value {
            0 => Side::Black,
            _ => Side::White,
        }
    }

    pub fn value(&self) -> usize {
        match self {
            Side::Black => 0,
            Side::White => 1,
        }
    }

    pub fn next(&self) -> Self {
        match self {
            Side::Black => Side::White,
            Side::White => Side::Black,
        }
    }
}
