use super::Entity;
use crate::api::{AllyTeam, Output, Plan, PosList, LIFE_SCORE};
use std::hash::{Hash, Hasher};

#[derive(Clone, Debug)]
pub struct Team {
    pub reward_real: i32,      // 不含过量伤害的真实得分
    pub reward_fake: i32,      // 包含过量伤害的虚假得分
    pub entities: Vec<Entity>, // 所有角色
}

impl Hash for Team {
    fn hash<H: Hasher>(&self, state: &mut H) {
        self.reward_real.hash(state);
        self.reward_fake.hash(state);
        self.entities.hash(state);
    }
}

impl PartialEq for Team {
    fn eq(&self, other: &Self) -> bool {
        self.reward_real == other.reward_real
            && self.reward_fake == other.reward_fake
            && self.entities == other.entities
    }
}

impl Eq for Team {}

impl Team {
    pub fn new(score: i32, entities: Vec<Entity>) -> Self {
        Self {
            reward_real: score,
            reward_fake: score,
            entities,
        }
    }

    pub fn output(&self) -> Output {
        Output {
            soldiers: self
                .alives()
                .iter()
                .map(|e| Plan {
                    id: e.id,
                    path: e.path.clone()[1..e.path.len()].to_vec(),
                })
                .collect(),
        }
    }

    /// 清理运行数据
    pub fn clear(&mut self) {
        for entity in self.alives_mut().iter_mut() {
            entity.clear();
        }
    }

    pub fn life_score(&self) -> i32 {
        let lifes: i32 = self.entities.iter().map(|e| e.life + 1).sum();
        lifes * LIFE_SCORE
    }

    pub fn real_score(&self) -> i32 {
        self.life_score() + self.reward_real
    }

    pub fn alives(&self) -> Vec<&Entity> {
        self.entities.iter().filter(|e| !e.dead()).collect()
    }

    pub fn alives_mut(&mut self) -> Vec<&mut Entity> {
        self.entities.iter_mut().filter(|e| !e.dead()).collect()
    }
}

impl From<AllyTeam> for Team {
    fn from(ally: AllyTeam) -> Self {
        Self::new(
            ally.score,
            ally.entities
                .into_iter()
                .enumerate()
                .map(|e| e.into())
                .collect(),
        )
    }
}

impl From<Team> for AllyTeam {
    fn from(team: Team) -> AllyTeam {
        AllyTeam {
            score: team.reward_real,
            id: "id".to_string(),
            name: "name".to_string(),
            entities: team.entities.into_iter().map(|e| e.into()).collect(),
        }
    }
}

impl From<(PosList, i32)> for Team {
    fn from((enemy, score): (PosList, i32)) -> Self {
        let entities = enemy
            .entities
            .into_iter()
            .enumerate()
            .map(|e| e.into())
            .collect();
        Self::new(score, entities)
    }
}

impl From<Team> for PosList {
    fn from(team: Team) -> PosList {
        PosList {
            entities: team
                .entities
                .into_iter()
                .filter(|e| !e.dead())
                .map(|e| e.into())
                .collect(),
        }
    }
}
