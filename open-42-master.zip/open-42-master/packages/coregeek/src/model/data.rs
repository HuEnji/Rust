use burn::tensor::{backend::Backend, Data, Shape, Tensor};

use crate::{
    api::{Dir, DIR_NUM, MAP_SIZE, ROUND_NUM},
    game::State,
    util,
};

pub const CHANNEL_NUM: usize = 8;
pub const CHANNEL_NAME: [&str; CHANNEL_NUM] = [
    "SPACE",
    "SELF POS",
    "SELF BFS",
    "ENEMY POS",
    "ENEMY ATTACKABLE",
    "ALLY POS",
    "ALLY HEALTH",
    "ALLY LIFE",
];
pub const INFO_NUM: usize = 4;
pub const INFO_NAME: [&str; INFO_NUM] = ["ROUND", "SIDE", "HEALTH", "LIFE"];

#[derive(Clone, Debug)]
pub struct InputData<B: Backend> {
    pub board: Tensor<B, 4>,
    pub info: Tensor<B, 2>,
}

impl<B: Backend> Default for InputData<B>
where
    B::FloatElem: From<f32>,
{
    fn default() -> Self {
        Self {
            board: Tensor::zeros(Shape {
                dims: [1, CHANNEL_NUM, MAP_SIZE, MAP_SIZE],
            }),
            info: Tensor::zeros(Shape {
                dims: [1, INFO_NUM],
            }),
        }
    }
}

impl<B: Backend> InputData<B>
where
    B::FloatElem: From<f32>,
    f32: From<B::FloatElem>,
{
    pub fn extract(state: &State, index: usize) -> InputData<B> {
        fn board_index(channel: usize, x: usize, y: usize) -> usize {
            channel * MAP_SIZE * MAP_SIZE + x * MAP_SIZE + y
        }
        let zero = B::FloatElem::from(0.0);
        let one = B::FloatElem::from(1.0);
        let (ally, enemy) = state.teams();
        let a = &ally.entities[index];
        debug_assert!(!a.dead());
        let mut board = Data::new(
            vec![zero; CHANNEL_NUM * MAP_SIZE * MAP_SIZE],
            Shape {
                dims: [1, CHANNEL_NUM, MAP_SIZE, MAP_SIZE],
            },
        );
        let mut info = Data::new(
            vec![zero; INFO_NUM],
            Shape {
                dims: [1, INFO_NUM],
            },
        );

        for (x, line) in state.map.iter().enumerate() {
            for (y, &v) in line.iter().enumerate() {
                if v == 0 {
                    debug_assert!("SPACE" == CHANNEL_NAME[0]);
                    board.value[board_index(0, x, y)] = one;
                }
            }
        }

        debug_assert!("SELF POS" == CHANNEL_NAME[1]);
        board.value[board_index(1, a.pos.x as usize, a.pos.y as usize)] = one;

        let bfs = state.bfs_ally(index);
        for (x, line) in bfs.iter().enumerate() {
            for (y, &v) in line.iter().enumerate() {
                if v != 0 {
                    debug_assert!("SELF BFS" == CHANNEL_NAME[2]);
                    board.value[board_index(2, x, y)] = one;
                }
            }
        }
        for (ei, e) in enemy.entities.iter().enumerate() {
            debug_assert!("ENEMY POS" == CHANNEL_NAME[3]);
            board.value[board_index(3, e.pos.x as usize, e.pos.y as usize)] = one;

            if !a.attacked[ei] && e.health > 0 {
                for pos in e.pos.neighbors() {
                    if bfs[pos.x as usize][pos.y as usize] != 0 {
                        debug_assert!("ENEMY ATTACKABLE" == CHANNEL_NAME[4]);
                        board.value[board_index(4, pos.x as usize, pos.y as usize)] = one;
                    }
                }
            }
        }

        for (ei, e) in ally.entities.iter().enumerate() {
            if ei == index {
                continue;
            }
            debug_assert!("ALLY POS" == CHANNEL_NAME[5]);
            board.value[board_index(5, e.pos.x as usize, e.pos.y as usize)] = one;
            debug_assert!("ALLY HEALTH" == CHANNEL_NAME[6]);
            board.value[board_index(6, e.pos.x as usize, e.pos.y as usize)] =
                B::FloatElem::from(e.health as f32);
            debug_assert!("ALLY LIFE" == CHANNEL_NAME[7]);
            board.value[board_index(7, e.pos.x as usize, e.pos.y as usize)] =
                B::FloatElem::from(e.life as f32);
        }

        info.value[0] = (ROUND_NUM as f32 - state.round as f32).into();
        info.value[1] = match state.side {
            crate::game::Side::Black => one,
            crate::game::Side::White => zero,
        };
        info.value[2] = (a.health as f32).into();
        info.value[3] = (a.life as f32).into();
        InputData {
            board: Tensor::from_data(board),
            info: Tensor::from_data(info),
        }
    }

    pub fn print(&self) {
        let boards = self.board.to_data().value;
        let infos = self.info.to_data().value;
        for (b, (board, info)) in boards
            .chunks(CHANNEL_NUM * MAP_SIZE * MAP_SIZE)
            .zip(infos.chunks(INFO_NUM))
            .enumerate()
        {
            println!("BATCH: {}", b);
            for (c, chunk) in board.chunks(MAP_SIZE * MAP_SIZE).enumerate() {
                println!("CHANNEL: {}", CHANNEL_NAME[c]);
                let mut map = [[0; MAP_SIZE]; MAP_SIZE];
                for (x, row) in chunk.chunks(MAP_SIZE).enumerate() {
                    for (y, v) in row.iter().enumerate() {
                        let v: f32 = (*v).into();
                        let v = v as u8;
                        map[x][y] = v;
                    }
                }
                util::print_map(&map);
            }
            for (i, v) in info.iter().enumerate() {
                let v: f32 = (*v).into();
                print!("{}: {} ", INFO_NAME[i], v);
            }
            println!();
        }
    }
}

impl<B: Backend> InputData<B> {
    pub fn combine(data: Vec<InputData<B>>) -> Self {
        let len = data.len();
        let mut boards = Vec::with_capacity(len);
        let mut infos = Vec::with_capacity(len);
        for item in data.into_iter() {
            boards.push(item.board);
            infos.push(item.info);
        }
        Self {
            board: Tensor::cat(boards, 0),
            info: Tensor::cat(infos, 0),
        }
    }
}

#[derive(Clone, Debug)]
pub struct OutputData<B: Backend> {
    pub q: Tensor<B, 2>,
    pub value: Tensor<B, 1>,
}

impl<B: Backend> OutputData<B>
where
    usize: TryFrom<B::IntElem>,
    f32: From<B::FloatElem>,
{
    pub fn values(&self) -> Vec<[f32; DIR_NUM]> {
        let value: Vec<f32> = self
            .q
            .to_data()
            .value
            .into_iter()
            .map(|x| x.into())
            .collect();
        value
            .chunks(DIR_NUM)
            .map(|chunk| chunk.try_into().unwrap())
            .collect()
    }

    pub fn actions(&self) -> Vec<usize> {
        let x = Tensor::argmax(self.q.clone(), 1);
        let x = x.flatten::<1>(0, 1);
        let data = x.into_data();
        data.value
            .into_iter()
            .map(|a| usize::try_from(a).unwrap_or(Dir::N.value()))
            .collect()
    }
}

#[derive(Clone, Debug)]
pub struct SumData<B: Backend> {
    pub values: Tensor<B, 1>,
}

#[cfg(test)]
mod tests {
    use crate::{
        api::{Dir, STEP_NUM},
        game::{Action, State},
        Backend,
    };

    use super::InputData;

    #[test]
    fn extract() {
        let mut state = State::gen();
        for _ in 0..STEP_NUM {
            let mut step = vec![];
            for e in state.ally().alives().iter() {
                let data = InputData::<Backend>::extract(&state, e.index);
                data.print();
                step.push(Action {
                    index: e.index,
                    dir: Dir::random(),
                });
            }
            let _ = state.exec_step(step.clone());
        }
    }
}
