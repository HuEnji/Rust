use burn::tensor::backend::Backend;

use crate::{
    game::State,
    model::{Dqn, InputData},
    InferResult, Model,
};

impl<B: Backend> Model for Dqn<B>
where
    B::FloatElem: From<f32>,
    f32: From<B::FloatElem>,
    usize: TryFrom<B::IntElem>,
{
    fn infer(&self, state: &State) -> InferResult {
        let entities = &state.ally().alives();
        let len = entities.len();
        let mut inputs = vec![];
        for e in entities.iter() {
            inputs.push(InputData::extract(state, e.index));
        }
        let input = match len.cmp(&1) {
            std::cmp::Ordering::Less => panic!("empty input"),
            std::cmp::Ordering::Equal => inputs.remove(0),
            std::cmp::Ordering::Greater => InputData::combine(inputs),
        };
        let output = self.forward(input);
        InferResult {
            values: output.values(),
            actions: output.actions(),
        }
    }
}
