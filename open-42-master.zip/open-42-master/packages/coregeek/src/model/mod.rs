mod data;
mod infer;

pub use data::*;

use burn::{
    module::Module,
    nn,
    record::{DefaultRecorder, Recorder},
    tensor::{backend::Backend, Int, Shape, Tensor},
};
use log::*;
use std::path::Path;

use crate::api::{DIR_NUM, ENTITY_NUM, MAP_SIZE};

#[derive(Module, Debug)]
pub struct Dqn<B: Backend> {
    conv1: nn::conv::Conv2d<B>,
    conv2: nn::conv::Conv2d<B>,
    conv3: nn::conv::Conv2d<B>,
    conv4: nn::conv::Conv2d<B>,
    fc1: nn::Linear<B>,
    fc2: nn::Linear<B>,
    fc3: nn::Linear<B>,
    fc4: nn::Linear<B>,
    actions: nn::Linear<B>,
    value: nn::Linear<B>,
    relu: nn::ReLU,
}

impl<B: Backend> Default for Dqn<B> {
    fn default() -> Self {
        const CONV_WIDTH: usize = 16;
        const DENSE_WIDTH: usize = 256;

        let mut prev = CHANNEL_NUM;
        let mut next = CONV_WIDTH;
        let conv1 = nn::conv::Conv2dConfig::new([prev, next], [3, 3])
            .with_padding(nn::PaddingConfig2d::Same)
            .init();

        prev = next;
        next = CONV_WIDTH;
        let conv2 = nn::conv::Conv2dConfig::new([prev, next], [3, 3])
            .with_padding(nn::PaddingConfig2d::Same)
            .init();

        prev = next;
        next = CONV_WIDTH;
        let conv3 = nn::conv::Conv2dConfig::new([prev, next], [3, 3])
            .with_padding(nn::PaddingConfig2d::Same)
            .init();

        prev = next;
        next = CONV_WIDTH;
        let conv4 = nn::conv::Conv2dConfig::new([prev, next], [3, 3])
            .with_padding(nn::PaddingConfig2d::Same)
            .init();

        let flatten = next * MAP_SIZE * MAP_SIZE;
        let concat = flatten + INFO_NUM;

        prev = concat;
        next = DENSE_WIDTH;
        let fc1 = nn::LinearConfig::new(prev, next).init();

        prev = next;
        next = DENSE_WIDTH;
        let fc2 = nn::LinearConfig::new(prev, next).init();

        prev = next;
        next = DENSE_WIDTH;
        let fc3 = nn::LinearConfig::new(prev, next).init();

        prev = next;
        next = DENSE_WIDTH;
        let fc4 = nn::LinearConfig::new(prev, next).init();

        prev = DENSE_WIDTH;
        next = DIR_NUM;
        let action = nn::LinearConfig::new(prev, next).init();

        prev = DENSE_WIDTH;
        next = 1;
        let value = nn::LinearConfig::new(prev, next).init();
        let relu = nn::ReLU::new();
        Self {
            conv1,
            conv2,
            conv3,
            conv4,
            fc1,
            fc2,
            fc3,
            fc4,
            actions: action,
            value,
            relu,
        }
    }
}

impl<B: Backend> Dqn<B>
where
    B::FloatElem: From<f32>,
{
    pub fn load<P: AsRef<Path>>(path: P) -> Self {
        let path = path.as_ref().to_path_buf();
        info!("load model from: {:?}", path);
        let model = Dqn::default();
        let recorder = DefaultRecorder::new();
        let record = recorder.load::<DqnRecord<B>>(path).unwrap();
        model.load_record(record)
    }

    pub fn save<P: AsRef<Path>>(&self, path: P) {
        let recorder = DefaultRecorder::new();
        let record = self.clone().into_record();
        recorder
            .record(record, path.as_ref().to_path_buf())
            .unwrap();
    }

    pub fn forward(&self, input: InputData<B>) -> OutputData<B> {
        // 卷积层
        let x = input.board;
        let x = self.conv1.forward(x);
        let x = self.relu.forward(x);
        let x = self.conv2.forward(x);
        let x = self.relu.forward(x);
        let x = self.conv3.forward(x);
        let x = self.relu.forward(x);
        let x = self.conv4.forward(x);
        let x = self.relu.forward(x);

        // flatten
        let [batch_size, channels, height, width] = x.dims();
        let x = x.reshape([batch_size, channels * height * width]);

        // 加入info
        let x = Tensor::cat(vec![x, input.info], 1);

        // 全连接层
        let x = self.fc1.forward(x);
        let x = self.relu.forward(x);
        let x = self.fc2.forward(x);
        let x = self.relu.forward(x);
        let x = self.fc3.forward(x);
        let x = self.relu.forward(x);
        let x = self.fc4.forward(x);
        let x = self.relu.forward(x);

        // 估值输出
        let value = self.value.forward(x.clone());
        // 策略输出
        let action = self.actions.forward(x);
        // 策略优势
        let mean = action.clone().mean_dim(1);
        let advantage = action - mean;

        // 估值+优势
        let q = value.clone() + advantage;
        let value = value.squeeze(1);
        OutputData { q, value }
    }

    // 计算总评分
    pub fn value(&self, input: InputData<B>) -> SumData<B> {
        let output = self.forward(input);
        let values = output.value;
        let num = values.shape().dims[0];
        debug_assert!(num % ENTITY_NUM == 0);
        let batch = values.shape().dims[0] / ENTITY_NUM;
        let values = values.reshape(Shape {
            dims: [batch, ENTITY_NUM],
        });
        let values = Tensor::sum_dim(values, 1);
        let values = Tensor::squeeze(values, 1);
        SumData { values }
    }

    // 计算各动作得分之和
    pub fn sum(&self, input: InputData<B>, actions: Tensor<B, 3, Int>) -> Tensor<B, 3> {
        let output = self.forward(input);
        // [[v0..v8]; B * ENTITY_NUM]
        let values = output.q;

        let num = values.shape().dims[0];
        debug_assert!(num % ENTITY_NUM == 0);
        let batch = num / ENTITY_NUM;
        // [[[v0..v8]; ENTITY_NUM]; B]
        let values = values.reshape(Shape {
            dims: [batch, ENTITY_NUM, DIR_NUM],
        });

        // [[[value]; ENTITY_NUM]; B]
        let values = values.gather(2, actions);
        // [[[sum]]; B]
        Tensor::sum_dim(values, 1)
    }
}

#[cfg(test)]
mod tests {
    use super::Dqn;
    use crate::Backend;
    use std::fs;

    #[test]
    fn create() {
        let model = Dqn::<Backend>::default();
        fs::create_dir_all("model").unwrap();
        model.save("model/best");
    }
}
