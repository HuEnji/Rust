use std::sync::Arc;

use crate::{
    api::{Dir, DIR_NUM, STEP_NUM},
    combine::{ActionScore, IndexCombine, IndexCombineScore, StepPriority},
    game::State,
    InferResult, Model,
};

#[derive(Default)]
pub struct RandomModel {}
impl Model for RandomModel {
    fn infer(&self, state: &State) -> InferResult {
        let mut values = vec![];
        let mut actions = vec![];
        for _ in state.ally().alives().iter() {
            let mut value = [0.0; DIR_NUM];
            let action = Dir::random().value();
            value[action] = 1.0;
            values.push(value);
            actions.push(action);
        }
        InferResult { values, actions }
    }
}

#[derive(Default)]
pub struct StayModel {}
impl Model for StayModel {
    fn infer(&self, state: &State) -> InferResult {
        let mut values = vec![];
        let mut actions = vec![];
        for _ in state.ally().alives().iter() {
            let mut value = [0.0; DIR_NUM];
            let action = Dir::N.value();
            value[action] = 1.0;
            values.push(value);
            actions.push(action);
        }
        InferResult { values, actions }
    }
}

#[derive(Default)]
pub struct GreedyModel {}
impl Model for GreedyModel {
    fn infer(&self, state: &State) -> InferResult {
        let mut values = vec![];
        let mut actions = vec![];
        for e in state.ally().alives().iter() {
            let limit = (STEP_NUM - state.ally_steps.len()) as u8;
            let attacks_bfs = state.bfs_attackables(e.index);
            let mut value = Dir::sample();
            let prev = e.pos;
            for (a, v) in value.iter_mut().enumerate() {
                let dir = Dir::from(a);
                if !state.valid_action(e.index, dir) {
                    *v *= -128.0;
                    continue;
                }
                let next = prev + dir.delta();
                let dp = attacks_bfs[prev.x as usize][prev.y as usize];
                let dn = attacks_bfs[next.x as usize][next.y as usize];
                // 得分
                if dn == 1 {
                    *v *= 1024.0;
                    continue;
                }
                // 进攻
                if dn > 0 && dn < limit && dn < dp {
                    *v *= 128.0;
                    continue;
                }
                // 防守
                let dp = state.enemy_bfs[prev.x as usize][prev.y as usize];
                let dn = state.enemy_bfs[next.x as usize][next.y as usize];
                if dn > 0 || dp > 0 {
                    match dn.cmp(&dp) {
                        std::cmp::Ordering::Less => *v *= 16.0,
                        std::cmp::Ordering::Equal => (),
                        std::cmp::Ordering::Greater => *v /= 16.0,
                    }
                    continue;
                }
                // 聚集
                let mut dp = 0;
                let mut dn = 0;
                for mate in state.ally().alives().iter() {
                    if mate.index == e.index {
                        continue;
                    }
                    dp += mate.pos.chebyshev(&prev);
                    dn += mate.pos.chebyshev(&next);
                }
                match dn.cmp(&dp) {
                    std::cmp::Ordering::Less => *v *= 8.0,
                    std::cmp::Ordering::Equal => (),
                    std::cmp::Ordering::Greater => *v /= 8.0,
                }
            }
            let action = value
                .iter()
                .enumerate()
                .max_by(|a, b| a.1.partial_cmp(b.1).unwrap())
                .map(|(i, _)| i)
                .unwrap();
            values.push(value);
            actions.push(action);
        }
        InferResult { values, actions }
    }
}

pub struct WrapModel {
    pub model: Arc<dyn Model>, // 模型
    pub width: usize,          // 每个角色的可选动作数
}
impl WrapModel {
    fn force(
        state: &State,
        table: &Vec<StepPriority>,
        combines: &mut Vec<IndexCombineScore>,
        combine: IndexCombine,
        index: usize,
    ) {
        // 递归终点
        if index >= table.len() {
            // 检查无效
            let step = combine.step(table);
            if !state.valid_step(&step) {
                return;
            }
            // 计算得分
            let score = combine.score(table);
            // 创建子节点
            combines.push(IndexCombineScore { combine, score });
            return;
        }
        // 遍历所有动作递归
        for a in 0..table[index].actions.len() {
            let mut next = combine.clone();
            next.indexes[index] = a;
            Self::force(state, table, combines, next, index + 1);
        }
    }
}

impl Model for WrapModel {
    fn infer(&self, state: &State) -> InferResult {
        let entities = state.ally().alives();
        let result = self.model.infer(state);
        // 生成总动作表
        let mut table = vec![];
        for (entity, actions) in entities.iter().zip(result.values) {
            let stay = ActionScore {
                dir: Dir::N,
                score: actions[Dir::N.value()],
            };
            let mut scores = vec![];
            for (d, v) in actions.into_iter().enumerate() {
                if !state.valid_action(entity.index, Dir::from(d)) {
                    continue;
                }
                scores.push(ActionScore {
                    dir: Dir::from(d),
                    score: v,
                });
            }
            scores.sort_by(|a, b| b.score.partial_cmp(&a.score).unwrap());
            let mut scores: Vec<ActionScore> = scores.into_iter().take(self.width).collect();
            if !scores.iter().any(|s| s.dir == Dir::N) {
                scores[self.width - 1] = stay;
            }
            table.push(StepPriority {
                index: entity.index,
                actions: scores,
            });
        }

        let mut combines = vec![];

        Self::force(
            state,
            &table,
            &mut combines,
            IndexCombine {
                indexes: vec![0; table.len()],
            },
            0,
        );
        combines.sort_by(|a, b| b.score.partial_cmp(&a.score).unwrap());
        let best = combines.first().unwrap();
        let step = best.combine.step(&table);
        let mut values = vec![];
        let mut actions = vec![];
        for action in step.into_iter() {
            let a = action.dir.value();
            let mut value = [0.0; DIR_NUM];
            value[a] = 1.0;
            values.push(value);
            actions.push(a);
        }
        InferResult { values, actions }
    }
}
