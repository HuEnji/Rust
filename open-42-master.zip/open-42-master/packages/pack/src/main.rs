use std::fs;

use chrono::Local;
use pack::{copy_recursively, pack, replace_line};
use regex::Regex;

fn main() {
    // 复制coregeek
    fs::remove_dir_all("./target/CoreGeek/").unwrap_or(());
    copy_recursively("./packages/coregeek/", "./target/CoreGeek/").unwrap();
    copy_recursively("./Cargo.lock", "./target/CoreGeek/Cargo.lock").unwrap();

    // 复制整体代码
    fs::remove_dir_all("./target/42").unwrap_or(());
    copy_recursively("./packages", "./target/42/packages").unwrap();
    copy_recursively("./Cargo.lock", "./target/42/Cargo.lock").unwrap();
    copy_recursively("./Cargo.toml", "./target/42/Cargo.toml").unwrap();
    fs::remove_dir_all("./target/42/packages/coregeek/model").unwrap();

    // 记录时间戳
    let now = Local::now();
    let reg = Regex::new(r"^const TIMESTAMP: &str = .*;").unwrap();
    let rep = format!("const TIMESTAMP: &str = \"{}\";", now);
    let main = "./target/CoreGeek/src/main.rs";
    replace_line(main, &reg, &rep).unwrap();

    let root = "./target";
    let output = "./target/42.tar.gz";
    let files = [
        "CoreGeek/Cargo.toml",
        "CoreGeek/Cargo.lock",
        "CoreGeek/src",
        "CoreGeek/model/best.mpk.gz",
        "42",
    ];
    pack(&root, &output, &files).unwrap();
}
