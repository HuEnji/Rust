use std::{
    fs::{self, File},
    io::{self, BufRead, Write},
    path::Path,
};

use flate2::{write::GzEncoder, Compression};
use regex::Replacer;

pub fn replace_line<T: AsRef<Path>, R: Replacer + Copy>(
    input: T,
    reg: &regex::Regex,
    rep: R,
) -> io::Result<()> {
    let input = input.as_ref();
    let input_file = File::open(input)?;
    let mut input_reader = io::BufReader::new(input_file);

    let output = input.with_extension("tmp");
    let mut output_file = File::create(&output)?;

    let mut line = String::new();
    while input_reader.read_line(&mut line)? > 0 {
        line = reg.replace_all(&line, rep).to_string();
        output_file.write_all(line.as_bytes())?;
        line.clear();
    }
    fs::remove_file(input)?;
    fs::rename(output, input)?;
    Ok(())
}

pub fn copy_recursively<T: AsRef<Path>>(src: T, dst: T) -> io::Result<()> {
    let src = src.as_ref();
    let dst = dst.as_ref();
    if src.is_dir() {
        fs::create_dir_all(dst)?;
        for entry in fs::read_dir(src)? {
            let entry = entry?;
            copy_recursively(&entry.path(), &dst.join(entry.file_name()))?;
        }
    } else {
        fs::copy(src, dst)?;
    }
    Ok(())
}

pub fn pack<T: AsRef<Path>, R: AsRef<str>>(
    root: T,
    output: T,
    entries: &[R],
) -> std::io::Result<()> {
    let root = root.as_ref();
    let output = File::create(output)?;
    let encoder = GzEncoder::new(output, Compression::default());
    let mut builder = tar::Builder::new(encoder);

    for name in entries.iter() {
        let name = name.as_ref();
        let path = root.join(name);
        if !path.exists() {
            println!("{} not exist!", name);
            continue;
        }
        if path.is_file() {
            builder.append_file(name, &mut File::open(path)?)?;
        } else if path.is_dir() {
            builder.append_dir_all(name, path)?;
        }
    }
    builder.finish()?;
    Ok(())
}
