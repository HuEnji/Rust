#!/bin/bash

apt-get install gcc g++ pkg-config fontconfig libfontconfig-dev

set -e

export RUSTUP_UPDATE_ROOT=http://rust.inhuawei.com/rustup-static/rustup
export RUSTUP_DIST_SERVER=http://rust.inhuawei.com/rustup-static
export GIT_SSL_NO_VERIFY=true
export SSL_NO_VERIFY=true

curl -sSf http://rust.inhuawei.com/rustup-static/rustup-init.sh | bash -s -- -y
source $HOME/.cargo/env

MIRROR="[source.crates-io]
replace-with = 'mirror'
[source.mirror]
registry = \"https://mirrors.tools.huawei.com/rust/crates.io-index/\"
[net]
git-fetch-with-cli=true"

echo "$MIRROR" > $HOME/.cargo/config

cargo build --release

cargo fmt -- --check
cargo clippy --all-targets -- -D warnings

cargo test